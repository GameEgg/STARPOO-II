function update(){
	var check = 0;
	var tang = 0;
 	var rtt;
	var minr;
	var srtt;
	var er;
	var ern;
	var mrn;
	var mr;

	for (var i = myShips.length - 1; i >= 0; i--) {
		if(enemyShips.length == 0){
			var ship = myShips[i]
			ship.setSpeed(5)

			var goodR = groundRadius*3/5-i*1.5;
			var goodAngle = 90;	

			var p = polarFrom(ship,{x:0,y:0});	
			ship.setSpeed(5*p.r/goodR);
			if(p.r > goodR){
				goodAngle = 0;
			}
			ship.setAngleSpeed((p.angle-goodAngle)*50);
		}
		else{
			myShips[i].setSpeed(5);
			minr = 999999;
			for(var j = enemyShips.length - 1; j >= 0; j--) {
				rtt = polarFrom(myShips[i],enemyShips[j]);
				if(minr > rtt.r){
					minr = rtt.r;
					srtt = rtt;
				}
			}	
			myShips[i].setAngleSpeed(srtt.angle*60);
			check = 1;
			er = 0;
			ern = 0;
			for(var k = enemyShips.length - 1; k >= 0; k--) {
				rtt = polarFrom(myShips[i],enemyShips[k]);
				tang = rtt.angle;
				if((tang >=-20 && tang <20)){
					check = 0;
					er += rtt.r;
					ern++;
				}
			}
			mr = 0;
			mrn = 0;
			for(var k = myShips.length - 1; k >= 0; k--) {
				if(i != k){
					rtt = polarFrom(myShips[i],myShips[k]);
					tang = rtt.angle;
					if((tang >=-30 && tang <30)){
						check = 1;
						mr += rtt.r;
						mrn++;
					}	
				}
			}	
			if(check == 0){
				myShips[i].shoot();
			}
			else{
				myShips[i].setSpeed(2);
				if(er/ern < mr/mrn && er/ern != 0)
					myShips[i].shoot();
			}
		}
		
	}
}