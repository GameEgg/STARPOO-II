// JavaScript source code

function abs(a)
{
    if(a >= 0)
        return a;
    else
        return -a;
}

function update() {
    for (var i = 0; i < myShips.length; i++) {
        var ship = myShips[i];
        ship.setSpeed(5);
        if (enemyShips.length == 0) { continue; }
        var j;
        for (j = 0; j < bullets.length; j++) {
            //log(j);
            p = polarFrom({ x: bullets[j].x, y: bullets[j].y, angle: bullets[j].angle }, { x: ship.x, y: ship.y });
            if (p.angle < 5) {
                ship.setAngleSpeed(360);
                break;
            }
        }
        if (j != bullets.length)
            continue;

        eship = enemyShips[0];
        p = polarFrom(ship, eship);
        
        ship.setAngleSpeed(p.angle * 1.5);
        for (j = 0; j < myShips.length; j++) {

            if (j == i)
                continue;

            q = polarFrom(ship, myShips[j]);
            if (q.r < 1.5)
                ship.setAngleSpeed((random()) - 0.5 * 400);
        }

        if (abs(p.angle) < 10) {
            for (j = 0; j < myShips.length; j++) {
                
                if (j == i)
                    continue;
                
                p = polarFrom(ship, myShips[j]);
                
                
                //log(random());
                if (abs(p.angle)*abs(p.angle)*p.r < 250)
                    break;
            }
            if (j == myShips.length)
                ship.shoot();
        }
            
    }
}