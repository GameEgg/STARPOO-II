var tempmyShipx = [];
var tempmyShipy = [];

var sumx = 0;
var zero = 0;
var sumy = 0;
var middle = myShips.length/2;

for (var i = myShips.length - 1; i >= 0; i--) {
	
	sumx = sumx + myShips[i].x;
	sumy = sumy + myShips[i].y;	
}

var averx = sumx/myShips.length;
var avery = sumy/myShips.length;

var tp = polarFrom({x: averx, y: avery},{x:0, y:0});
var xp = polarFrom({x:0, y:0},{x:averx, y:avery});
//var yp = polarFrom({x:0, y:0},{x:averx, y:avery});



for (var i = 0; myShips.length - 1 >= i; i++) {
	
	//tempmyShipx[i] =  xp.r * cos(xp.angle + (middle - i) * 5);
	//tempmyShipy[i] =  xp.r * sin(xp.angle + (middle - i) * 5);
	//xp.r *
	
	if(tp.angle <= 270){
		
		//tempmyShipx[i] = dist({x:0,y:0} , {x:averx,y:avery}) * cos((middle - i)*5 + (tp.angle + 90));
		//tempmyShipy[i] = dist({x:0,y:0} , {x:averx,y:avery}) * sin((middle - i)*5+ (tp.angle + 90));
		
		tempmyShipx[i] = averx + 3 * (middle - i) * cos(tp.angle + 90);
		tempmyShipy[i] = avery + 3 * (middle - i) * sin(tp.angle + 90);
	}
	else{
		//tempmyShipx[i] = dist({x:0,y:0} , {x:averx,y:avery}) * cos((middle - i)*5 + (tp.angle - 90));
		//tempmyShipy[i] = dist({x:0,y:0} , {x:averx,y:avery}) * sin((middle - i)*5+ (tp.angle - 90));
		
		
		tempmyShipx[i] = averx + 3 * (middle - i) * cos(tp.angle - 90);
		tempmyShipy[i] = avery + 3 * (middle - i) * sin(tp.angle - 90);
	}
}


function translate( ship, destination ){
   var res = polarFrom( ship, destination );
   ship.setAngleSpeed(res.angle);
   ship.setSpeed(3);
}


var shipRadius = 0.7

function getKillAngleSize( shipFrom, shipTo ){
   var distance = dist(shipFrom, shipTo)
   var rad = Math.asin( shipRadius / distance )
   var deg = r2d(rad)
   return deg
}

function isAttackable( attacker, target ){
   var res = polarFrom( attacker, target )
   var warnRange = getKillAngleSize( attacker, target )
   
   if( Math.abs(res.angle) < warnRange )
      return true
   else
      return false
}




function update(){
	log("x is" + averx);
	log("y is" + avery);
	
	for (var i = myShips.length - 1; i >= 0; i--) {
		ship = myShips[i];
		var minimum = 999999;
		var temp2 = [];
		temp2[i] = -1;
		myShips[i].setSpeed(0);
		
		for (var j = enemyShips.length - 1; j >= 0; j--) {
			var temp;
			temp = dist({x:myShips[i].x, y:myShips[i].y},{x:enemyShips[j].x, y:enemyShips[j].y});
			
			if ( minimum > temp ){
				minimum = temp;
				temp2[i] = j;
			}
		}
		if(temp2[i] == -1){
			translate(myShips[i] , {x:tempmyShipx[i], y: tempmyShipy[i]});
		}
		
		if(temp2[i] != -1){
			p = polarFrom(myShips[i],{x:enemyShips[temp2[i]].x, y:enemyShips[temp2[i]].y});
			//if((myShips[i].angle)-5<p.angle && p.angle < (myShips[i].angle)+5){
			if(isAttackable( myShips[i] , {x:enemyShips[temp2[i]].x, y:enemyShips[temp2[i]].y})){
				ship.setAngleSpeed(0);
				ship.shoot();
			}
			else
				ship.setAngleSpeed(p.angle*10000);
			
			//if(isAttackable( myShips[i] , {x:enemyShips[temp2[i]].x, y:enemyShips[temp2[i]].y}))
				
		}

	}
}

//enemyShips : array<ship>
//allyShips : array<ship>
//myShips : array<myship> 
//myship : x,y,angle,speed,angleSpeed,hp,ammo
//bullets : array<bulley>


//ship : x,y,angle,hp
//bullet : x,y,speed,angle

//allyShip : x,y,angle,hp,

//function
//shoot() <- �Ѿ˽�
//setSpeed(number) : ���� �����ӷ�(0~5)
//setAngleSpeed(number) : ȸ���ӵ�()

//polarFrom(center,target) -> angle, r