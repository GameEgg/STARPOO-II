

function update(){

	var a = 0;

for (var i = myShips.length - 5; i >= 0; i--) {
	p = polarFrom(myShips[i],myShips[i+4]);

	if(p.r>30) a=1;
}

	if(a==1)
	{

		for (var i = myShips.length - 1; i >= 0; i--) {
			
			if(enemyShips.length == 0)
			{
				myShips[i].setSpeed(0);
	
				p = polarFrom(myShips[i],{x:0,y:0});
				myShips[i].setAngleSpeed(p.angle-20);
				if(i<myShips.length/4) myShips[i].setAngleSpeed(p.angle-20);
				if(i>myShips.length/2) myShips[i].setAngleSpeed(p.angle+20);
			} 
			else
			{
				p = polarFrom(myShips[i],enemyShips[0]);
				myShips[i].setAngleSpeed(p.angle);
			}

		}

		for (var i = myShips.length - 1; i >= 0; i--) {
			myShips[i].shoot();
		}

	}
	else
	{
		for (var i = myShips.length - 1; i >= 0; i--) {
		
		ship = myShips[i]
		ship.setSpeed(5)
		if(i<myShips.length/4) ship.setSpeed(2);
		if(i>myShips.length/2) ship.setSpeed(4);

		var goodR = 45;
		var goodAngle = 90;

		p = polarFrom(ship,{x:0,y:0});

		if(p.r > goodR){
			goodAngle = 0;
		}

		ship.setAngleSpeed((p.angle-goodAngle)*50);

		}

	}


}