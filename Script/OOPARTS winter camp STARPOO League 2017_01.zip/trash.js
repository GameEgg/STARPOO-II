﻿function ang_360(va){
	return (va < 0 ? 360 + va : va);//0~360
}

function tr_rotate_eval(a, b){
	if (b.y >= a.y && b.x >= a.x) return Math.atan(1.0 * (b.y - a.y) / (b.x - a.x) ) / 3.141592 * 180;
	else if (b.y >= a.y && b.x <= a.x) return 180 - Math.atan(1.0 * (b.y - a.y) / (a.x - b.x) ) / 3.141592 * 180;
	else if (b.y <= a.y && b.x <= a.x) return 180 + Math.atan(1.0 * (a.y - b.y) / (a.x - b.x) ) / 3.141592 * 180;
	else return 360 - Math.atan(1.0 * (a.y - b.y) / (b.x - a.x) ) / 3.141592 * 180;
}//(0~360사이값)

function tr_rotate(ship, dest){
	var ang = ang_360(ship.angle);
	var destrot = tr_rotate_eval(ship, dest);
	if (Math.abs(destrot - ang) > 170){
		ship.setAngleSpeed(360);
	}
	else{
		if (destrot - ang <= 180) ship.setAngleSpeed(2 * (destrot - ang));
		else ship.setAngleSpeed(destrot - ang);
	}
}

function isReadyToShot(src){
	var le = myShips.length;
	var ang = ang_360(src.angle);
	for (var i = 0; i < le; i++){
		if (Math.abs(tr_rotate_eval(src, myShips[i]) - ang) <= 10){
			return false;
		}
	}
	le = enemyShips.length;
	for (var i = 0; i < le; i++){
		if (Math.abs(tr_rotate_eval(src, enemyShips[i]) - ang) <= 30)
			return true;
	}
	return false;
}

var cnt = 10;

function update(){
	if (myShips.length == 0) return;
	if (cnt > 0){
		cnt--;
		init();
	}
	var le = myShips.length - 1;
	var gr = groundRadius * 17 / 20;
	var teemo = groundRadius * 3 / 5;
	var myloc = {x:0, y:0};
	ship = myShips[le];
	while(1){
		myloc.x = teemo * cos(360.0 / le * teemo_idx);
		myloc.y = teemo * sin(360.0 / le * teemo_idx);
		if (dist(ship, myloc) <= 2){
			teemo_idx = (teemo_idx + 1) % le;
			continue;
		}
		else{
			ship.setSpeed(5);
			tr_rotate(ship, myloc);
		}
		break;
	}

	for (var i = le - 1; i >= 0; i--) {
		myloc.x = gr * cos(myAngle + 30 / le * i);
		myloc.y = gr * sin(myAngle + 30 / le * i);
		ship = myShips[i];
		if (dist(ship, myloc) <= 3){
			ship.setSpeed(0);
			if (enemyShips.length > 0){
				tr_rotate(ship, enemyShips[0]);
	
				if (isReadyToShot(ship)){
					ship.shoot();
				}
			}
			else{
				ship.setAngleSpeed(360);
			}
		}
		else{
			ship.setSpeed(5);
			tr_rotate(ship, myloc);
		}
	}
}

var myAngle = 0;
var teemo_idx = 0;
var avgx = 0;
var avgy = 0;

function init(){
	var le = myShips.length;
	for (var i = 0; i < le; i++){
		avgx += myShips[i].x;
		avgy += myShips[i].y;
	}
	avgx /= le;
	avgy /= le;
	myAngle = tr_rotate_eval({x:0, y:0}, {x:avgx, y:avgy});
}

init();

//enemyShips : array<ship>
//allyShips : array<ship>
//myShips : array<myship> 
//myship : x,y,angle,speed,angleSpeed,hp,ammo
//bullets : array<bulley>


//ship : x,y,angle,hp
//bullet : x,y,speed,angle

//allyShip : x,y,angle,hp,

//function
//shoot() <- 총알쏨
//setSpeed(number) : 배의 전진속력(0~5)
//setAngleSpeed(number) : 회전속도()

//polarFrom(center,target) -> angle, r