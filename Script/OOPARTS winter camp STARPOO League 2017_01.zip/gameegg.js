var normal_offset = 0;
var t = 0;
var evadeTime = 0;

var normalP;
var normalD;
setAR();
function p2d(p){
	return {x:sin(p.angle)*p.r, y:cos(p.angle)*p.r}
}
function setAR(){
	normalP = {angle:random()*360,r:groundRadius*random()*0.8}
	normalD = p2d(normalP);
}
function normal(ship,i){
	// var centerD = getCenter(myShips);
	// var centerP = polar(centerD);
	// if(dist(centerD,normalD) < 6){
	// 	setAR();
	// }
	var numX = Math.floor(Math.sqrt(myShips.length));
	var targetPos = {x:normalD.x+(i%numX)*2.5,y:normalD.y+(Math.floor(i/numX))*2.5}
	lookPos(ship,targetPos)
	if(dist(ship,targetPos)){
		setAR();
	}

	ship.setSpeed(shipMaxSpeed);
}

function checkFacingAlly(ship){
	for(var i = 0; i < allyShips.length; ++i){
		var ally = allyShips[i];
		if(ally.x == ship.x && ally.y == ship.y) continue;

		var p = polarFrom(ship,ally);

		if(Math.abs(p.angle) > 80){
			continue;
		}

		if(1 > Math.abs(sin(Math.abs(p.angle)))*p.r && p.r < 9){
			return p.r;
		}
	}
	return Number.MAX_VALUE;
}

function attackEnemy(ship,index){
	for(var i = 0; i < enemyShips.length; ++i){
		var enemy = enemyShips[i];
		var d = dist(ship,enemy);
		if(d < 3){
			if(evadeTime > 0)
				ship.setSpeed(5)
			else
				ship.setSpeed(0);
			shootToEnemy(ship,enemy,index);
			return true;
		}
		else if(d < 60){
			ship.setSpeed(5);
			shootToEnemy(ship,enemy,index);
			return true;
		}

	}
	return false;
}

function evade(ship,array,d){
	var target = null;
	var nearest = 99999;
	for(var i = 0; i < array.length; ++i){
		var item = array[i];
		var p = polarFrom(item,ship);

		if(Math.abs(p.angle) > 80){
			continue;
		}
		if(0.8 < sin(Math.abs(p.angle))*p.r || p.r > d){
			continue;
		}

		if(nearest > p.r){
			nearest = p.r;
			target = item;
		}
	}
	if(target != null){
		var a = polarFrom(ship,target).angle;
		if(a < 0 && a > -90 || a > 90 && a < 180){
			lookPos(ship,target,-90);
		}
		else{
			lookPos(ship,target,90);
		}
		if(Math.abs(a) > 30){
			ship.setSpeed(5);
		}
		else{
			ship.setSpeed(0);
		}
	}
}


function update(){
	t += dt;
	for (var i = 0; i <myShips.length; ++i) {
		var ship = myShips[i];
		if(evadeTime > 0){
			evade(ship,bullets);
			evadeTime -= dt;
			return;
		}
		if(enemyShips.length <= 0){
			normal(ship,i);
		}
		if(ship.ammo < 1){
			evade(ship,bullets,7);
			evade(ship,allyShips,3);
			evade(ship,enemyShips,3);
		}
		else{
			var attacking = attackEnemy(ship,i);
			if(!attacking) 
				normal(ship,i);
			evade(ship,bullets,7);
		}
	}
}

function lookAngle(ship,angle){
	angle%=360;
	if(Math.abs(angle-ship.angle) > Math.abs(ship.angle-(angle-360))){
		angle -= 360;
	}
	var v = (angle-ship.angle)/dt;
	ship.setAngleSpeed(v);
	return v < 360;
}

function lookPos(ship,pos,angle){
	if(angle == null){
		angle = 0;
	}
	p = polarFrom(ship,pos);
	var a = p.angle-angle;
	a %= 360;
	if(a > 180){
		a -= 360;
	}
	else if(a < -180){
		a += 360;
	}
	var v = a/dt;
	ship.setAngleSpeed(v);
	return v < 360;
}

function shootToEnemy(ship,enemy,index){
	var pos;
	var distance = dist(ship,enemy);
	pos = enemy;
	var shootable = lookPos(ship,pos);

	var notfacingAlly = distance<checkFacingAlly(ship);
	if(shootable && distance<8){
		if(notfacingAlly){
			if(ship.shoot()){
				evadeTime = 0;
			}
		}
		else{
			var centerEE = getCenter(enemyShips);
			ship.setSpeed(5)
			var anan;
			if(index%2 == 0){
				anan = 90
			}
			else{
				anan = -90
			}
			lookPos(ship,centerEE,anan);
		}
	}
}

function virtualPos(ship,d){
	var v = {
		x:ship.x + cos(ship.angle)*d,
		y:ship.y + sin(ship.angle)*d
	};

	return v;
}

function getCenter(arr){
	var x = 0;
	var y = 0;
	for (var i = arr.length - 1; i >= 0; i--) {
		var ship = arr[i];
		x += ship.x;
		y += ship.y;
	}
	x /= arr.length;
	y /= arr.length;
	return {x:x,y:y};
}
