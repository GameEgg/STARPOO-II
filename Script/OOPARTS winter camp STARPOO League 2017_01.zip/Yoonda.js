/*16척 배틀 기준*/
//업데이트 밖에 있는 건 시작할 때 한 번만 실행된다.



/*function Square_Formation(Squradron[4]){
	
	//Squradron.[i].setSpeed(5);
	
}*/

var Alpha=[], Bravo=[], Charlie=[], Delta=[];

function Direction(ship,angle,speed)
{
	p = polarFrom(ship,{x:0,y:0});
	ship.setAngleSpeed((p.angle-angle)*50);

	ship.setSpeed(speed);
}//특정 각으로 특정 속도로 중앙을 향해 보냄.

function Init(){
	
if(enemyShips.length===0 && myShips.length===16){ //상대발견못한초반 ->전개
Direction(myShips[0],0,4);
Direction(myShips[1],0,4);
Direction(myShips[2],0,4);
Direction(myShips[3],0,4);

Direction(myShips[5],0,4);
Direction(myShips[6],0,4);

Direction(myShips[9],0,4);
Direction(myShips[10],0,4);

Direction(myShips[13],0,4);
Direction(myShips[14],0,4);

Direction(myShips[4],-30,5);	
Direction(myShips[8],-60,5);
Direction(myShips[12],-90,5);

Direction(myShips[7],30,5);
Direction(myShips[11],60,5);
Direction(myShips[15],90,5);
}
/*if(enemyShips.length===0 && myShips.length!=16){ //내 배는 손상이 있는데 상대를 아직 발견 못함

}*/
}


function Squradron_Init(){
	if(enemyShips.length===0 && myShips.length===16){
	Alpha[0]=myShips[4];
	Alpha[1]=myShips[8];
	Alpha[2]=myShips[12];
	
	Bravo[0]=myShips[0];
	Bravo[1]=myShips[1];
	Bravo[2]=myShips[2];
	Bravo[3]=myShips[3];
	
	Charlie[0]=myShips[7];
	Charlie[1]=myShips[11];
	Charlie[2]=myShips[15];
	
	Delta[0]=myShips[5];
	Delta[1]=myShips[6];
	Delta[2]=myShips[9];
	Delta[3]=myShips[10];
	Delta[4]=myShips[13];
	Delta[5]=myShips[14];
	}
	
}


function Follow(ship1,ship2){
	p = polarFrom(ship1,{x:ship2.x,y:ship2.y});
	if (p.r <4){
	ship1.setSpeed(0);
	}
	else
	{
	ship1.setSpeed(5);
	}
	ship1.setAngleSpeed((p.angle)/50); // 상대를 쫒아감.
}

function Turret(myShip,targetShip){
	myShip.setSpeed(0);
	var p = polarFrom(myShip ,{x:targetShip.x, y:targetShip.y});
	myShip.setAngleSpeed(p.angle/50)
	myShip.shoot();
}


function Chase(ship){
	var closest_dist = dist({x:ship.x,y:ship.y},{x:enemyShips[0].x,y:enemyShips[0].y});
	var closest = 0;
	var current_dist = 0;
	for(var i=0;i<=enemyShips.length-1;i++)
	{
	 current_dist = dist({x:ship.x,y:ship.y},{x:enemyShips[i].x,y:enemyShips[i].y});
	 if (current_dist<closest_dist){
		 closest_dist = current_dist;
		 closest = i;
	 }
	}
	Follow(ship,enemyShips[closest]);
	ship.shoot();
}


function update(){
	try
	{
		update2()
	} catch (e)
	{
		log("---- exception! ----");
		log(e);
	}
}

function LookAt(myShip, targetShip){
	var p = polarFrom(myship ,{x:targetShip.x, y:targetShip.y});
	myShip.SetAngleSpeed(p.angle/25);	
}

function update2(){
	Init();
	Squradron_Init();
	
	if(enemyShips.length>0)
	{
		for(var i=0;i<Bravo.length;i++){
			Chase(Bravo[i]);
		}
		for(var i=0;i<Alpha.length;i++){
			Turret(Alpha[i],enemyShips[0]);
			/*var min;
			for(var k = 0 ; enemyShips.length; k++){
				
			if dist(x:enemyShips[k].x,y:enemyShips[k].y,x:Alpha[i].x, y:Alpha[i].y ) <
			Alpha[i].shoot;*/
			
			//}
			
			
		}
		for(var i=0;i<Charlie.length;i++){
			Turret(Charlie[i],enemyShips[0]);
		}
		for(var i=0;i<Delta.length;i++){
			Turret(Delta[i],enemyShips[0]);
		}
	}
}

//enemyShips : array<ship>
//allyShips : array<ship>
//myShips : array<myship> 
//myship : x,y,angle,speed,angleSpeed,hp,ammo
//bullets : array<bulley>


//ship : x,y,angle,hp
//bullet : x,y,speed,angle

//allyShip : x,y,angle,hp,

//function
//shoot() <- 총알쏨
//setSpeed(number) : 배의 전진속력(0~5)
//setAngleSpeed(number) : 회전속도()

//polarFrom(center,target) -> angle, r