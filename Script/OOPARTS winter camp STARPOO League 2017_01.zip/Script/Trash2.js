var eProcessState = {
    New : 0,
    Acting : 1,
    Finished : 2
}

var isFirstUpdate = true;
var unitHandleManager;
var commander = new Commander();
var radar = new Radar();
var attackDamage = shipMaxHp * 0.21;

function update(){
    if(isFirstUpdate){
        isFirstUpdate = false;
        InitProcess();
    }
    unitHandleManager.Update(myShips);
}

function InitProcess (){
    unitHandleManager = new CUnitHandleManager(myShips);
}

function CUnitHandleManager (units){

    this.unitHandles = new Array();
    this.isStartBroadCasted = false;

    for(var i in units){
        var newHandle = new CUnitHandle(units[i].id);
        this.unitHandles.push(newHandle);
    }

    this.Update = function(units){

        var aliveUnits = new Array();
        var curDestroyedUnits = new Array();

        for(var i in this.unitHandles){
            var isFound = false;

            for(var j in units){
                if(this.unitHandles[i].id == units[j].id)
                {
                    this.unitHandles[i].Init(units[j]);
                    aliveUnits.push(this.unitHandles[i]);
                    isFound = true;
                }
            }

            if(isFound == false){
                if(this.unitHandles[i].destroyChecked == false){
                    this.unitHandles[i].destroyChecked = true;
                    curDestroyedUnits.push(this.unitHandles[i]);
                }
            }
        }
        
        commander.Reset();
        radar.CheckTargetedUnit(aliveUnits);

        if(this.isStartBroadCasted == false){
            this.isStartBroadCasted = true;
            for(var i in aliveUnits){
                aliveUnits[i].Start();
            }
        }

        // 유닛 죽음 이벤트 발생
        if(curDestroyedUnits.length > 0){
            for(var i in aliveUnits){
                aliveUnits[i].OnDestroy(curDestroyedUnits);
            }
        }

        for(var i in aliveUnits){
            aliveUnits[i].Update();
        }

        commander.CommandAttack();

        for(var i in aliveUnits){
            aliveUnits[i].PostUpdate();
        }
    }
}

function CUnitHandle (id){
    this.id = id;
    this.destroyChecked = false; // Manager 에서 사용

    this.lastX = 0;
    this.lastY = 0;
    
    this.unit = null;
    this.process = null;

    this.isTargetedByTeam = false;
    this.isTargeted = false;        // 공격 당하려고 하고 있는가
    this.dangerShoot = null;        // 공격 당하는데 레이저 공격이 있는 경우
    this.attackTarget = null;       // 공격 명령이 있다면 그 대상

    this.Init = function(unit){
        this.attackTarget = null;
        this.lastX = unit.x;
        this.lastY = unit.y;
        this.unit = unit;
    }

    this.Start = function(unitHandle){
        this.process = new ObservingProcess();
    }

    this.Update = function(){
        if(this.process.processState == eProcessState.New){
            this.process.Start(this);
        }
        if(this.process.processState == eProcessState.Acting){
            this.process.Update(this);
        }
    }

    this.PostUpdate = function(){
        if(this.process.processState == eProcessState.Finished){
            if(this.process.childProcess != null)
                this.process = this.process.childProcess;
            else
                this.process = new ObservingProcess();
        }else{
            this.process.PostUpdate(this);
        }
    }

    this.OnDestroy = function(units){ // 이번 프레임에 죽은 유닛들의 리스트를 브로드 캐스트 받는다.
    }
}

function ObservingProcess() {
    this.processState = eProcessState.New;
    this.childProcess = null;

    this.isWaitingAttackCommand = false;
    this.targetPos = null;

    this.timer = 0;

    this.Start = function(unitHandle){
        this.processState = eProcessState.Acting;
        this.ResetTargetPos();
    }

    this.ResetTargetPos = function(){
        var rRandom = random();
        var rotRandom = random();
        var r = groundRadius - 100 - rRandom * 150; //rRandom * (groundRadius - 450) + 300;
        var rot = rotRandom * 360;
        this.timer = 1;
        this.targetPos = cartesian({r : r, rot : rot});
    }

    this.Update = function(unitHandle){
        if(this.timer <= 0){
            if (enemyShips.length > 0 && unitHandle.isTargeted == false && unitHandle.dangerShoot == null)
            {
                this.isWaitingAttackCommand = true;
                commander.RegisterAttack(unitHandle);
                return;
            }
        }
        else{
            this.timer -= dt;
        }
    }

    this.PostUpdate = function(unitHandle){
        if(unitHandle.attackTarget != null){
            this.childProcess = new AttackProcess(unitHandle.attackTarget);
            this.processState = eProcessState.Finished;
        }
        else{
            if(unitHandle.dangerShoot != null){
                this.childProcess = new AvoidingProcess(unitHandle.dangerShoot, unitHandle.unit);
                this.processState = eProcessState.Finished;
                return;
            }

            if(unitHandle.isTargeted){
                this.ResetTargetPos();
            }
            
            if(this.isWaitingAttackCommand == true){
                this.timer = 1;
                this.isWaitingAttackCommand = false;
            }else{
                this.Move(unitHandle);
            }
        }
    }

    this.Move = function(unitHandle){
        var rotR = polarFrom(unitHandle.unit, this.targetPos);
        
        var dist = shipMaxSpeed * dt;
        var nextX = unitHandle.unit.x + dist * cos(unitHandle.unit.rot);
        var nextY = unitHandle.unit.y + dist * sin(unitHandle.unit.rot);
        var nextRotR = polar({x : nextX, y : nextY});

        if(nextRotR.r > groundRadius - 30){
            this.ResetTargetPos();
        }

        var speed = shipMaxSpeed;
        var rotSpeed = shipMaxRotSpeed * Sign(rotR.rot);
        if(Math.abs(rotR.rot) < Math.abs(rotSpeed * dt)){
            rotSpeed = rotR.rot / dt;
        }

        if(rotR.r > 20){
            unitHandle.unit.setRotSpeed(rotSpeed);
            unitHandle.unit.setSpeed(speed);
        }else{
            this.ResetTargetPos();
        }
    }
}

function AvoidingProcess(shoot, unit){

    var rot = shoot.rot;
    var rotR = polarFrom(shoot, unit);

    if(sin(rotR.rot) * rotR.r < 0){
        rot -= 90;
    }else{
        rot += 90;
    }
    
    if(rot > 180)
        rot = rot - 360;
    else if(shoot.rot <-180)
        rot = rot + 360;
    
    this.targetRot = rot;
    this.movingTimer = 0.3;

    var movingDist = this.movingTimer * shipMaxSpeed;
    var nextX = unit.x + movingDist * cos(rot);
    var nextY = unit.y + movingDist * sin(rot);
    var nextRotR = polar({x : nextX, y : nextY});

    if(nextRotR.r > groundRadius - 30){
        this.childProcess = new ObservingProcess();
        this.processState = eProcessState.Finished;
    }else{
        this.childProcess = null;
        this.processState = eProcessState.New;
    }

    this.Start = function(unitHandle){
        this.processState = eProcessState.Acting;
    }

    this.Update = function(unitHandle){
        var difRot = this.targetRot - unitHandle.unit.rot;

        if(Math.abs(difRot) < 20 || Math.abs(difRot) > 340){
            unitHandle.unit.setSpeed(shipMaxSpeed);
            unitHandle.unit.setRotSpeed(0);
            this.movingTimer -= dt;
            if(this.movingTimer < 0){
                if(unitHandle.dangerShoot != null){
                    this.childProcess = new AvoidingProcess(unitHandle.dangerShoot, unitHandle.unit);
                    this.processState = eProcessState.Finished;
                }else{
                    this.childProcess = new ObservingProcess();
                    this.processState = eProcessState.Finished;
                }
            }
        }else{
            if (difRot > 180){
                difRot = -1 * (360 - difRot);
            }else if (difRot < -180){
                difRot = (360 + difRot);
            }

            var rotSpeed = shipMaxRotSpeed * Sign(difRot);
            if(Math.abs(difRot) < Math.abs(rotSpeed * dt)){
                rotSpeed = difRot / dt;
            }
            unitHandle.unit.setSpeed(0);
            unitHandle.unit.setRotSpeed(rotSpeed);
        }
    }
    
    this.PostUpdate = function(unitHandle){
    }
}

function AttackProcess(attackTarget){

    this.processState = eProcessState.New;
    this.childProcess = null;
    this.xy = {x : attackTarget.x, y : attackTarget.y};
    
    //var predXY = GetNextPos(attackTarget, attackDamage / chargingSpeed);
    //this.dXY = {x : predXY.x - this.xy.x, y : predXY.y - this.xy.y};

    this.targetPos = null;
    this.isCharging = false;
    this.isShootFinished = false;

    this.Start = function(unitHandle){
        this.processState = eProcessState.Acting;
        //this.targetPos = {x : unitHandle.unit.x + this.dXY.x, y : unitHandle.unit.y + this.dXY.y}; 
    }

    this.Update = function(unitHandle){
        var unit = unitHandle.unit;
        unit.setSpeed(0);
        if(unit.isCharging){
            this.isCharging = true;
            if(unitHandle.dangerShoot != null){
                this.childProcess = new AvoidingProcess(unitHandle.dangerShoot, unitHandle.unit);
                this.processState = eProcessState.Finished;
                return;
            }
            //this.Move(unitHandle);
        }else{
            if(this.isCharging){
                this.isCharging = false;
                this.isShootFinished = true;
                if(unitHandle.dangerShoot != null){
                    this.childProcess = new AvoidingProcess(unitHandle.dangerShoot, unitHandle.unit);
                    this.processState = eProcessState.Finished;
                }else{
                    this.childProcess = new ObservingProcess();
                    this.processState = eProcessState.Finished;
                }
            }else{
                var rotR = polarFrom(unitHandle.unit, this.xy);
                var rotSpeed = shipMaxRotSpeed * Sign(rotR.rot);
                if(rotR.rot < rotSpeed * dt){
                    rotSpeed = rotR.rot / dt;
                }
                
                if(Math.abs(rotR.rot) < 90){
                    var distance = sin(Math.abs(rotR.rot)) * rotR.r;
                    if(distance < 15){
                        unit.shoot(attackDamage);
                    }else{
                        unit.setRotSpeed(rotSpeed);
                    }
                }else{
                    unit.setRotSpeed(rotSpeed);
                }
                /*
                if(Math.abs(rotR.rot) < 5)
                    unit.shoot(attackDamage);
                else
                    unit.setRotSpeed(rotSpeed);*/
            }
        }
    }
    
    this.PostUpdate = function(unitHandle){
    }

    this.Move = function(unitHandle){
        var rotR = polarFrom(unitHandle.unit, this.targetPos);
        
        var speed = shipMaxSpeed;
        var rotSpeed = shipMaxRotSpeed * Sign(rotR.rot);
        if(Math.abs(rotR.rot) < Math.abs(rotSpeed * dt)){
            rotSpeed = rotR.rot / dt;
        }

        if(rotR.r > 10){
            unitHandle.unit.setRotSpeed(rotSpeed);
            unitHandle.unit.setSpeed(speed);
        }else{
            unitHandle.unit.setRotSpeed(0);
            unitHandle.unit.setSpeed(0);
        }
    }
}

function Commander(){
    
    this.attackableUnits = new Array();
    
    this.Reset = function(){
        this.attackableUnits = new Array();
    }

    this.RegisterAttack = function(unitHandle){
        this.attackableUnits.push(unitHandle);
    }

    this.CommandAttakInList = function(units, enemies){
        var usedEnemies = new Array();
        while(units.length > 0 /*&& enemies.length > 0*/){
            var each = units[0];
            units.splice(0, 1);

            enemies.sort(function(a, b){
                var aRotR = polarFrom(each.unit, a);
                var bRotR = polarFrom(each.unit, b);

                if(Math.abs(aRotR.rot) > Math.abs(bRotR.rot)){
                    return 1;
                }else if(Math.abs(aRotR.rot) == Math.abs(bRotR.rot)){
                    return 0;
                }else{
                    return -1;
                }
            });

            if(enemies.length == 0){
                enemies = usedEnemies;
                usedEnemies = new Array();
            }

            for(var j in enemies){
                var eachEnemy = enemies[j];
                var enemyRotR = polarFrom(each.unit, eachEnemy);
                var shoot = {x : each.unit.x, y : each.unit.y, rot : each.unit.rot + enemyRotR.rot};

                var isThereTeam = false;
                for(var i in myShips){
                    var eachTeamShip = myShips[i];

                    if(eachTeamShip.id == each.id)
                        continue;

                    var rotR = polarFrom(shoot, eachTeamShip);

                    if(Math.abs(rotR.rot) < 90){
                        var distance = sin(Math.abs(rotR.rot)) * rotR.r;
                        if(distance < 20){
                            isThereTeam = true;
                            break;
                        }
                    }
                }
                if(isThereTeam)
                    continue;
                else{
                    each.attackTarget = eachEnemy;
                    usedEnemies.push(eachEnemy);
                    enemies.splice(j , 1);
                    break;
                }
            }
        }
    }

    this.CommandAttack = function(){
        var unAllocatedEnemies = new Array();
        for(var i in enemyShips){
            unAllocatedEnemies.push(enemyShips[i]);
        }

        this.CommandAttakInList(this.attackableUnits, unAllocatedEnemies);
    }
}

function Radar(){
    this.CheckTargetedUnit = function(unitHandles){
        for(var i in unitHandles){
            var each = unitHandles[i];
            each.isTargeted = false;
            each.dangerShoot = null;

            for(var j in enemyShips){
                var eachEnemyUnit = enemyShips[j];

                var rotR = null;
                var shoot = null;

                if(eachEnemyUnit.isCharging){
                    var newShoot = {x:eachEnemyUnit.x, y:eachEnemyUnit.y, rot:eachEnemyUnit.shootingRot};
                    rotR = polarFrom(newShoot, each.unit);
                    shoot = newShoot;
                }else{
                    rotR = polarFrom(eachEnemyUnit, each.unit);
                    //shoot = eachEnemyUnit;
                }

                if(Math.abs(rotR.rot) < 90){
                    var distance = sin(Math.abs(rotR.rot)) * rotR.r;

                    if(distance < 20){
                        if(each.unit.isDetected){
                            each.isTargeted = true;
                            each.dangerShoot = shoot;
                        }else if(eachEnemyUnit.isCharging){
                            each.isTargeted = true;
                            each.dangerShoot = shoot;
                        }
                    }
                }
            }
        }

        for(var i in unitHandles){
            var each = unitHandles[i];
            each.isTargetedByTeam = false;

            for(var j in unitHandles){
                var eachTeamUnit = unitHandles[j].unit;
                if(eachTeamUnit.id == each.unit.id)
                    continue;

                if(eachTeamUnit.isCharging == false)
                    continue;
                
                var shoot = {x:eachTeamUnit.x, y:eachTeamUnit.y, rot:eachTeamUnit.shootingRot};
                var shootTime = (eachTeamUnit.shootingPower - eachTeamUnit.chargedPower) / chargingSpeed;
                var xy = GetNextPos(each.unit, shootTime);
                var rotR = polarFrom(shoot, xy);
                
                if(Math.abs(rotR.rot) < 90){
                    var distance = sin(Math.abs(rotR.rot)) * rotR.r;
                    
                    if(distance < 20){
                        each.isTargetedByTeam = true;
                        each.dangerShoot = shoot;
                    }
                }
            }
        }
    }
}

function GetNextPos(unit, t){
    var speed = unit.spd;
    var rotSpeed = unit.rotSpd;
    var c = 180 / (Math.PI * rotSpeed);
    
    var x = c * speed * Math.sin(t / c);
    var y = c * speed * (1 - Math.cos(t / c));
    
    return {x : unit.x + x, y : unit.y + y};
}

function Sign(value){
    if(value > 0)
        return 1;
    else if(value == 0)
        return 0;
    else
        return -1;
}