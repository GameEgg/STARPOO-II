function update(){

	myShips.forEach(function(myShip){
		if(enemyShips.length == 0)
			searchEnemy(myShip);
		else
			attackEnemy(myShip);
	});
}

function searchEnemy(myShip){
		var ship = myShip
		ship.setSpeed(shipMaxSpeed)

		var goodR = 20;
		var goodRot = 89;

		var p = polarFrom(ship,{x:0,y:0});

		if(p.r > goodR){
			goodAngle = 0;
		}
		ship.setRotSpeed((p.rot-goodRot)/dt);
}

function attackEnemy(myShip){
	myShip.setSpeed(0);

	var targetPoint = enemyShips[0];
	var polarFromShip = polarFrom(myShip,targetPoint);
	myShip.setRotSpeed(polarFromShip.rot/dt);

	if(myShips.length < 4){
		var p;
		var ch = 0;
		for(var i = 0; i < enemyShips.length;i++){
			if(Math.tan(enemyShips[i].rad)*(myShip.x-enemyShips[i].x)+enemyShips[i].y-myShip.y <= 0 && Math.tan(enemyShips[i].rad)*(myShip.x-enemyShips[i].x)+enemyShips[i].y-myShip.y > -20){
				p = polarFrom(myShip,enemyShips[i]);
				ch = 1;
			}
			if(Math.tan(enemyShips[i].rad)*(myShip.x-enemyShips[i].x)+enemyShips[i].y-myShip.y > 0 && Math.tan(enemyShips[i].rad)*(myShip.x-enemyShips[i].x)+enemyShips[i].y-myShip.y < 20){
				p = polarFrom(myShip,enemyShips[i]);
				ch = 1;
			}
			if(Math.tan(enemyShips[i].shootingRad )*(myShip.x-enemyShips[i].x)+enemyShips[i].y-myShip.y <= 0 && Math.tan(enemyShips[i].shootingRad )*(myShip.x-enemyShips[i].x)+enemyShips[i].y-myShip.y > -20){
				p = polarFrom(myShip,enemyShips[i]);
				ch = 1;
			}
			if(Math.tan(enemyShips[i].shootingRad )*(myShip.x-enemyShips[i].x)+enemyShips[i].y-myShip.y > 0 && Math.tan(enemyShips[i].shootingRad )*(myShip.x-enemyShips[i].x)+enemyShips[i].y-myShip.y < 20){
				p = polarFrom(myShip,enemyShips[i]);
				ch = 1;
			}
			if(ch == 1){
				ship.setRotSpeed((p.rot-90)/dt);
			}
		}
	}
	else{
		if(Math.abs(polarFromShip.rot) < 0.01){
			myShip.shoot(5);
		}
	}	
}

