var right = false;
var rightCheck = false;

var exit = false;
var triggered = true;
var singular = 7;//9
var secSingular = 2;

var specialTrigger = false;
var specialChecked = false;

function update(){
	if (!rightCheck) {
		if (myShips[0].x < 0)
			right = false;
		else
			right = true;
		rightCheck = true;
	}
	if ((specialTrigger == true) && (specialTrigger == false)){
		triggered = false;
		specialTrigger = true;
	}
	if (myShips.length >= singular) {
		if(specialTrigger == false) {
			if (enemyShips.length > 0){
				triggered = true;
			}
		}
		myShips.forEach(function(myShip, index){
			if((enemyShips.length == 0) || (myShip.delay != 0)){
				if (triggered){
					emptyRailShoot(myShip, index);
					//if(myShip.delay == 0)
					//triggered = false;
				}
				else{
					cranemoving(myShip, index);
				}
			} else {
	            railShoot(myShip, index);
	        }
		});
		if((myShips.length >= 12) || (myShips.length <= 9))
			bait(myShips[0]);
	} else if(myShips.length >= secSingular) {
		myShips.forEach(function(myShip, index){
			if((enemyShips.length == 0) || (myShip.delay != 0))
	            cranemoving(myShip, index);
	        else
	            rapidShoot(myShip, index);
		});
		//if(enemyShips.length == 0)
		bait(myShips[0]);
	} else {
		myShips.forEach(function(myShip, index){
			specialMoving(myShip, index);
		});
	}

}


function bait(myShip){
	myShip.setSpeed(300);

	var goodR = 20;
	var goodRot = 90;

	var p = polarFrom(myShip,{x:0,y:0});

	//if(p.r > goodR){
	//	goodRot = 0;
	//}
	myShip.setRotSpeed((p.rot-goodRot)/dt);
}

function cranemoving(myShip, index){
	
	if(myShips.length >= singular) {
		if (right) {
			var targetDegree = index * 160 / myShips.length - 80;
		}
		else {
			var targetDegree = index * 160 / myShips.length + 100;
		}
   		var targetR = groundRadius * 0.8;
	} else {
		var targetDegree = index * 360 / myShips.length;
		var targetR = groundRadius * 0.4;
	}

    var targetPoint = cartesian({r:targetR,rot:targetDegree});
    warigari(targetPoint);
    //log(targetPoint.x, targetPoint.y);
    var polarFromShip = polarFrom(myShip,targetPoint);
    //if ((specialTrigger == true) && ((index == 3) || (index == 2) || (index == 1)) && (polarFromShip.r < 100)) {
    //	triggered = true;
    //}
    myShip.setRotSpeed(polarFromShip.rot/dt);
    myShip.setSpeed(polarFromShip.r/dt);

}

function specialMoving(myShip, index){
	var targetPoint = {x:0, y:0};
    var polarFromShip = polarFrom(myShip,targetPoint);

    myShip.setRotSpeed(polarFromShip.rot/dt);
    myShip.setSpeed(polarFromShip.r/dt);

}

function warigari(targetPoint){

	targetPoint.x += (0.5-random())*200*groundRadius/1200;
	targetPoint.y += (0.5-random())*200*groundRadius/1200;
}

function emptyRailShoot(myShip, index){
	if(!myShip.isCharging && (myShip.delay == 0)){
		if (specialTrigger == false){
			if(right){
				var targetPoint = {x:-10000, y:myShip.y};
			} else {
				var targetPoint = {x:10000, y:myShip.y};
			}
		} else {
			if(right){
				var targetPoint = {x:myShip.x, y:-10000};
			} else {
				var targetPoint = {x:myShip.x, y:-10000};
			}
		}

	    var polarFromShip = polarFrom(myShip,targetPoint);
	    myShip.setRotSpeed(polarFromShip.rot/dt);

	    if(Math.abs(polarFromShip.rot) < 5){
	        myShip.shoot(5);
	    }
	} else {
		cranemoving(myShip, index);
	}
	
}

function railShoot(myShip, index){	
	if(!myShip.isCharging){
		myShip.setSpeed(30);

		if (specialTrigger == false){
			if(right){
				if (enemyShips[0].x < -100) {
					var targetPoint = {x:enemyShips[0].x, y:enemyShips[0].y};
				} else {
					var targetPoint = {x:-10000, y:enemyShips[0].y};
				}
			} else {
				if (enemyShips[0].x > 100) {
					var targetPoint = {x:enemyShips[0].x, y:enemyShips[0].y};
				} else {
					var targetPoint = {x:10000, y:enemyShips[0].y};
				}
				
			}
		} else {
			if(right){
				var targetPoint = {x:enemyShips[0].x, y:-10000};
			} else {
				var targetPoint = {x:enemyShips[0].x, y:-10000};
			}
		}


	    var polarFromShip = polarFrom(myShip,targetPoint);
	    myShip.setRotSpeed(polarFromShip.rot/dt);

	    if(Math.abs(polarFromShip.rot) < 5){
	        myShip.shoot(5);
	    }
	} else {
		cranemoving(myShip, index);
	}
}

function rapidShoot(myShip, index){
	//if(!myShip.isCharging){
	myShip.setSpeed(100);

	var targetPoint = enemyShips[0];
	var polarFromShip = polarFrom(myShip,targetPoint);
	myShip.setRotSpeed(polarFromShip.rot/dt);

	if(Math.abs(polarFromShip.rot) < 0.1){
	    myShip.shoot(0.2);
	}
}