function update(){
	for (var i = myShips.length - 1; i >= 0; i--) {
		var ship = myShips[i]

		var goodR = 20;
		var goodRot = 0;

		var r = -180 + 360*i/myShips.length;

		var p = polarFrom(ship,{x:-groundRadius*0.6 + cos(r)*groundRadius*0.35,y: + sin(r)*groundRadius*0.35});

		if(p.r > goodR){
			goodAngle = 0;
		}
		ship.setSpeed(p.r/dt);
		if(p.r < 1)
			ship.setSpeed(0);
		ship.setRotSpeed((p.rot-goodRot)/dt);
	}
}