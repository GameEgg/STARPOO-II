var totalTime = 0;
var SHIP_R_safe = 30;
var SHIP_R_target = 15;
var POWER = 0.13;
var POWER_not_detected = 0.13;
var MUDA_DELAY = 0.04;
var zero = vec(0,0);
var STATES = {};
var powerShooter = false;



function updateMyShip(ship,i)
{
	if(ship.isCharging){
		lookNextTarget(ship);
		return;
	}
	var power = computeShootable(ship);
	if(power > 0 && ship.delay === 0)
	{
		ship.setSpeed(0);
		ship.setRotSpeed(0);
		ship.shoot(power);
	}
	else
	{
		if(enemyShips.length === 0)
		{

			if(i == 0)
				freeMoveAndAttack(ship);
			else if(i == 1)
				specialScout(ship);
			else if(ship.delay < MUDA_DELAY && attackGoodTarget(ship)){

			}
			else
				moveAndShootAsSniper(ship,i);
		}
		else
		{
			if(ship.isDetected && ship.delay < MUDA_DELAY && attackGoodTarget(ship)){

			}
			else{
				if(i == 0)
					freeMoveAndAttack(ship);
				else
					moveAndShootAsSniper(ship,i);
			}
		}
	}
}

function specialScout(ship){
	var p = polarFrom(ship,zero);
	var ppp = (p.r > groundRadius*0.9) ? 0.9 : (p.r < groundRadius*0.7) ? 1.2 : 0
	ship.setRotSpeed(p.rot+90*ppp);
	ship.setSpeed(shipMaxSpeed);
}

function lookNextTarget(ship){
	ship.setSpeed(0);
	attackGoodTarget(ship);
}

function sign(n){
	return n < 0 ? -1 : 1;
}

function normalizeRot(rot){
	rot%=360;
	if(rot < -180)
		rot += 360;
	else if(rot > 180)
		rot -= 360;
	return rot;
}

function moveAndShootAsSniper(ship,i){
	if(ship.sniperComplete == undefined){
		ship.sniperComplete = false;
	}
	if(myShips.length < initCount*0.5){
		freeMoveAndAttack(ship);
		return;
	}

	try{
		if(ship.delay < 0){
			if(basicEvade(ship) || attackGoodTarget(ship)){
				return;
			}
		}

		var myPolar = polarFrom(ship,zero);
		var targetRot;
		if(i < myShips.length/2){
			targetRot = (180*0.8)*i/myShips.length+60 + sign(startRot)*10;
		}
		else{
			targetRot = (180*0.8)*i/myShips.length+170 - sign(startRot)*10;
		}
		var targetRotDist = normalizeRot(targetRot - polar(ship).rot);
		var rrr;
		if(myPolar.r < groundRadius*0.8)
			rrr = 120;
		else
			rrr = (myPolar.r < groundRadius*0.87) ? 95 : 70;

		var condzero1 = myPolar.r > groundRadius*0.9 && Math.abs(myPolar.rot) > 92;
		var condzero2 = myPolar.r < groundRadius*0.85 && Math.abs(myPolar.rot) < 85;
		//llog(ship,3,Math.floor(Math.abs(targetRotDist))+" : "+ Math.floor(myPolar.r) +" > "+ Math.floor(groundRadius*0.85))
		if(Math.abs(targetRotDist) < 15 && myPolar.r > groundRadius*0.85 && attackGoodTarget(ship)){
		}
		else if(condzero1 || condzero2){
			ship.setSpeed(0);
			ship.setRotSpeed((myPolar.rot+rrr * sign(-targetRotDist))/dt);
		}
		else{
			ship.setSpeed(shipMaxSpeed);
			ship.setRotSpeed((myPolar.rot+rrr * sign(-targetRotDist))/dt);
		}
	}
	catch(e){
		log("moveAndShootAsSniper-----------------!"+e);
	}
}

function lookEnemy(ship,p,range){
	try{
		ship.setSpeed(0);
		if(ship.rotSpd >= 0 && p.rot < -range){
			ship.setRotSpeed(-shipMaxRotSpeed*0.7);
			
		}
		else if(ship.rotSpd <= 0 && p.rot > range){
			ship.setRotSpeed(shipMaxRotSpeed*0.7);
			
		}
		else if(Math.abs(ship.rotSpd) < shipMaxRotSpeed * 0.4){
			ship.setRotSpeed(shipMaxRotSpeed*sign(p.rot)*0.7);
		}
	}
	catch(e){
		log("lookEnemy-----------------!"+e);
	}
}

function findBestTarget(ship){
	if(enemyShips.length == 0) return null;

	var minShip = null;
	var bestScore = -999999990;
	for(var i = 0; i < enemyShips.length; ++i){
		var enemy = futurePosEnemy( enemyShips[i], POWER/chargingSpeed );
		var p = polarFrom(ship,enemy);
		if(minShip === null){
			minShip = enemy;
			bestScore = score(p);
			continue;
		}
		var thisScore = score(p);
		if(bestScore < thisScore){
			minShip = enemy;
			bestScore = thisScore;
		}
	}
	return minShip;
}

function attackGoodTarget(ship)
{
	var nearestEnemy = findBestTarget(ship);

	if(nearestEnemy == null)
		return false;

	ship.setRotSpeed(polarFrom(ship,nearestEnemy).rot/dt);
	if(!ship.isCharging && polar(ship).r < groundRadius*0.85){
		ship.setSpeed(shipMaxSpeed);
	}
	else{
		ship.setSpeed(0);
	}
	var power = computeShootable(ship);
	if(power > 0){
		ship.shoot(Math.min(power,nearestEnemy.hp));
		return true;
	}
	return true;
}

function basicEvade(ship){
	for(var i = 0; i < enemyShips.length; ++i){
		var enemy = enemyShips[i];
		if(enemy.isCharging && enemy.shootingPower >= shipMaxHp * 0.9){
			var shootingEnemy = vec(enemy.x,enemy.y);
			shootingEnemy.rot = enemy.shootingRot;
			var p = polarFrom(shootingEnemy,ship);
			if(sin(p.rot)*p.r < SHIP_R_safe*1.1){
				ship.setRotSpeed((polarFrom(ship,enemy).rot-90)/dt);
				return true;
			}
		}
	}
	return false;
}

function freeMoveAndAttack(ship)
{
	if(ship.delay < MUDA_DELAY && attackGoodTarget(ship)){
		return;
	}
	if(basicEvade(ship)){
		return;
	}
	if(ship.nextPos === undefined || dist(ship,ship.nextPos) < shipMaxSpeed*dt || ship.nextPosDur > 1.2)
	{
		ship.nextPos = cartesian({r:random()*groundRadius*0.8,rot:360*random()});
		ship.nextPosDur = 0;
		if(polar(ship.nextPos).r > groundRadius*0.9)
		{
			ship.nextPos = undefined;
			freeMoveAndAttack(ship);
			return;
		}
	}

	var p = polarFrom(ship,ship.nextPos);
	var pzero = polarFrom(ship,zero);
	if(Math.abs(pzero.rot) > 89 && pzero.r > groundRadius * 0.9){
		ship.setSpeed(0);
	}
	else{
		ship.setSpeed(shipMaxSpeed);
	}
	ship.nextPosDur += dt;
	ship.setRotSpeed(p.rot/dt);

}


function computeShootable(ship){
	if(ship.delay > 0) 
		return 0;
	for(var i = 0; i < enemyShips.length;++i){
		var enemy = enemyShips[i];
		var future = futurePosEnemy(enemy,POWER/chargingSpeed);
		var power = (ship.isDetected) ? POWER : POWER_not_detected;
		if(future === null){
			power = 0;
		}
		if(enemy.isCharging){
			var chargingDur = (enemy.shootingPower-enemy.chargedPower)*0.5;
			power += chargingDur;
			future = enemy;
		}
		if(future === null)
			continue;
		var polarFuture = polarFrom(ship,future);
		if((Math.abs(polarFuture.rot) < 60) && (sin(Math.abs(polarFuture.rot))*polarFuture.r < SHIP_R_target)){
			if(checkSafeShootable(ship,power/chargingSpeed)){
				return power;
			}
		}
	}
	return 0;
}

function checkSafeShootable(ship,t){
	for(var i = 0; i < myShips.length;++i){
		var mine = myShips[i];
		if(mine.id == ship.id)
			continue;

		var future = futurePosMine(mine,t);
		var polarFuture = polarFrom(ship,future);
		var shootR = sin(Math.abs(polarFuture.rot))*polarFuture.r;
		if((Math.abs(polarFuture.rot) < 70) && shootR < SHIP_R_safe)
		{
			return false;
		}
	}
	return true;
}

function llog(ship,i,str){
	if(myShips[i] !== null){
		if(ship.id == myShips[i].id){
			log(str);
		}
	}
}


function futurePosMine(ship,t)
{
	var middleR = (ship.rot + ship.rotSpd*t)*0.5;
	var dx = cos(middleR)*ship.spd*t;
	var dy = sin(middleR)*ship.spd*t;


	return vec(ship.x+dx,ship.y+dy);
}

function futurePosEnemy(ship,t){

	var prev = EnemyHistory.get(ship.id);
	if(prev !== null){
		var dx = ship.x-prev.x;
		var dy = ship.y-prev.y;
		var rotSpd = (ship.rot-prev.rot)/dt;
		var spd = dist(zero,vec(dx,dy))/dt;
		var futureR = ship.rot + rotSpd*t;

		var futureX = 0;
		var futureY = 0;
		var virtualR = ship.rot;

		for(var i = 0; i < t; i +=dt){
			virtualR += rotSpd*dt;
			futureX += cos(virtualR)*spd*dt;
			futureY += sin(virtualR)*spd*dt;
		}
		futureX += cos(ship.rot)*spd*dt;
		futureY += sin(ship.rot)*spd*dt;
		return vec(ship.x+futureX,ship.y+futureY);
	}
	else{
		var futureX = cos(ship.rot)*t*shipMaxSpeed*0.8;
		var futureY = sin(ship.rot)*t*shipMaxSpeed*0.8;
		return vec(ship.x+futureX,ship.y+futureY);
	}
}

function vec(x,y){
	return {x:x,y:y};
}


function shootEnemy(){

}

var EnemyHistory = {
	history:[],
	update:function()
	{
		for(var i = 0; i < enemyShips.length; ++i){
			var enemy = enemyShips[i];
			var hist = null;
			for(var j = 0; j < this.history.length; ++j){
				var checkingItem = this.history[j];
				if(checkingItem.id == enemy.id){
					hist = checkingItem;
				}
			}
			if(hist === null){
				hist = {id:enemy.id,x:enemy.x,y:enemy.y,rot:enemy.rot,t:totalTime};
				this.history.push(hist);
			}
			else{
				hist.x = enemy.x;
				hist.y = enemy.y;
				hist.rot = enemy.rot;
				hist.t = totalTime;
			}
		}
	},
	get:function(id){
		for(var j = 0; j < this.history.length; ++j){
			var checkingItem = this.history[j];
			if(checkingItem.id == id){
				if(checkingItem.t >= totalTime-dt*1.5){
					return checkingItem;
				}
				else{
					return null;
				}
			}
		}
		return null;
	}
};

var Finder = {
	getMyShip:function(id){
		for(var i = 0; i < myShips.length; ++i){
			if(myShips[i].id == id){
				return myShips[id];
			}
		}
	},
	getEnemyShip:function(id){
		for(var i = 0; i < enemyShips.length; ++i){
			if(enemyShips[i].id == id){
				return enemyShips[id];
			}
		}
	}
};



function score(p,hp){
	var score = 0;
	return -(p.r)*0.01 - Math.abs(p.rot)*0.2-hp*0.5
}

var initCount = 0;
var startRot;
function init(){
	if(initCount != 0){
		initCount = myShips.length;
		startRot = myShips[0].rot;
	}
}

function update()
{
	init();
	totalTime += dt;//업뎃 1줄 고정

	myShips.forEach(updateMyShip);

	EnemyHistory.update();//마지막
}