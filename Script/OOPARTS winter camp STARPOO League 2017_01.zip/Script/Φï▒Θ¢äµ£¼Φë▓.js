var idle_myShips = [];
var busy_myShips = [];
var free_enemyShips = [];
var targetReports = [];
var b_init = false;

function update() {
    if(!b_init){
        b_init = true;
        init();
    }
    updateIdle_myShips();
    updateFree_enemyShips();
    
    reCheckTargetReport();

    matchingTarget();

    idle_myShips.forEach(moveArround, this);

    if(enemyShips.length >= 1){
        myShips.forEach(function(myShip,index){
            attackEnemy(myShip,index);
    });

    }

    log("히어로즈 오브 더 스톰가입시전원 카드팩뒷면100%증정월드오브 워크래프트펫 무료증정특정조건디아블로3공허의유산초상화획득기회즉시이동http:kr.battle.net/heroes/ko/");
}

function init() {
    myShips.forEach(function(ship, index) {
        // idle_myShips.push(ship);
        // ship.setSpeed();
    }, this);
}

function updateIdle_myShips() {
    // Clean Up idle_myShips Array
    idle_myShips.splice(0, idle_myShips.length);

    myShips.forEach(function(ship, index) {    
        if (!ship.isCharging) {
            idle_myShips.push(ship);
        }
        // log(idle_myShips[idle_myShips.length - 1].id + " of " + idle_myShips.length);
    }, this);
}

function updateFree_enemyShips() {
    var cursor = 0;
    free_enemyShips.splice(0, free_enemyShips.length);
    
    for (var i = 0; i < enemyShips.length; i++) {
        for (; cursor < targetReports.length; ) {
            if (enemyShips[i].id > targetReports[cursor].enemyShip.id) {
                cursor++;
                continue;
            }
            if (enemyShips[i].id < targetReports[cursor].enemyShip.id) {
                break;
            }
            else if (enemyShips[i].id == targetReports[cursor].enemyShip.id) {
                free_enemyShips.push(enemyShips[i]);
                cursor++;
                break;
            }
        }
    }
}

function reCheckTargetReport() {
    for (var i = 0; i < targetReports.length;) {
        if (isExistInArray(idle_myShips, targetReports[i].myShip)) {
            targetReports.splice(i, 1);
        }
        else {
            i++;
        }
    }
}

function movePoint(ship, destination) {
    var pos = polarFrom(ship, destination);

    if (pos.r > 0.1) {
        ship.setSpeed(pos.r / dt)
        ship.setRotSpeed(pos.rot / dt);
    }
    else {
        ship.setRotSpeed(0);
        ship.setSpeed(0);
    }
}

function moveArround(ship, index) {
    var pos = polarFrom(ship, {x: 0, y: 0});
    ship.setSpeed(shipMaxSpeed);

    var destR = groundRadius * (index + 1) / (idle_myShips.length + 1);
    var correctionR = ((pos.r - destR) / groundRadius) * 360;

    if (ship.id % 2 == 0) {
        ship.setRotSpeed((pos.rot - 90 + correctionR) / dt);
    }
    else {
        ship.setRotSpeed((pos.rot + 90 - correctionR) / dt);
    }
}

function getBestAgent(targetShip) {
    var bestAgent = null;
    var bestRot = 180;
    var bestDist = 2 * groundRadius;

    idle_myShips.forEach(function(ship, index) {
         var distance = dist(ship, targetShip);
         if (distance < bestDist) {
             bestDist = distance;
             bestAgent = ship;
         }
    }, this);

    return bestAgent;
}

function matchingTarget() {
    for (var i = 0; i < free_enemyShips.length; i++) {
        var bestAgent = getBestAgent(free_enemyShips[i]);
        if (bestAgent != null) {
            var report;
            report.myShip = bestAgent;
            report.enemyShip = free_enemyShips[i];
            
            targetReports.Add(report);
        }
    }
}

function isExistInArray(array, object) {
    for (var i = 0; i < array.length; i++) {
        if (array[i] == object) {
            // array.splice(i, 1);
            return true;
        }
    }
    return false;
}

function getShip(ships, id) {
    for (var i = 0; i < ships.length; i++) {
        if (ships[i].id = id) {
            return ships[i];
        }
    }
    return null;
}

function attackEnemy(myShip,index){
    myShip.setSpeed(60);

    var jndex = enemyShips.length / index;

    for(var j = 0; j < enemyShips.length -1 ; j++){


    }

    var targetPoint = enemyShips[0];
    var polarFromShip = polarFrom(myShip,targetPoint);
    myShip.setRotSpeed(polarFromShip.rot/dt);

    if(Math.abs(polarFromShip.rot) < 0.01){
        myShip.shoot(1.7);
    }
}