﻿function update()
{
    
    myShips.stop = false;
    myShips.avoid=false;
    myShips.target;
    myShips.forEach(function (myShip, index) {
        var point1 = polarFrom(myShip, { x: 0, y: 0 }).rot;
        var point2 = polarFrom(myShip, { x: myShip.x * 2, y: myShip.y * 2 }).rot;
        var distt = dist(myShip, { x: 0, y: 0 });
     
        if (distt > groundRadius * 0.97&&(Math.abs(myShip.rot - point2) + 360) % 360 < 120);
       else if (enemyShips.length == 0 && myShip.stop == false)
            search(myShip);
       
       else if (enemyShips.length != 0 && distt < groundRadius * 0.97)
           attack(myShip);
      
        //바깥향하고있을시 속도 0 
        if (distt > groundRadius * 0.97 && (Math.abs(myShip.rot - point2) + 360) % 360 < 90 && (Math.abs(myShip.rot - point2) + 360) % 360 > 270) { myShip.setSpeed(30); myShip.setRotSpeed(500); myShip.stop = true; }
        else if (distt > groundRadius * 0.94 && (Math.abs(myShip.rot - point2) + 360) % 360 > 90) {myShip.setSpeed(200); myShip.setRotSpeed(0); }
        else if (distt < groundRadius * 0.94) { myShip.speed = 500; myShip.stop = false; }

    });

}


function search(myShip)
{
    myShip.setRotSpeed(myShip.id % 5 * 35);
        myShip.setSpeed(500);
}

function attack(myShip)
{
    var targetPoint = nearship(myShip);
    if (targetPoint != null) {
        var distt = dist(myShip, targetPoint);
        
        var polarFromShip = polarFrom(myShip, targetPoint);
        if (Math.abs(polarFromShip.rot) < 0.1 && myShip.delay == 0 && distt < 90) {
            myShip.shoot(0.5);
            myShip.avoid = true;
            //  myShip.target = nearship(myShip);
        }
            /* else if(myShip.isCharging==true)
             {
                 if (distance(myShip, myShip.enemyShip))
                     ;
             }
             else if(myShip.delay>0)
             {
         
             }*/
        else if (myShip.delay == 0 || (((targetPoint.shootingPower - targetPoint.chargedPower) < 0.3) && ((targetPoint.shootingPower - targetPoint.chargedPower) > 0))) {
            if (polarFromShip.rot > 0)
                myShip.setRotSpeed(200);
            else
                myShip.setRotSpeed(-200);
        }
    }

}

function nearship(myShip)
{
    var near;
    var dist1;
    var dist2;
    near = enemyShips[0];
    if(enemyShips.length>1)
    for(var i=1;i<enemyShips.length;++i)
    {
        dist1=dist(myShip,enemyShips[i-1]);
        dist2=dist(myShip,enemyShips[i]);
        
        if (dist1 > dist2)
            near = enemyShips[i];
    }
    var distt = dist(myShip, near);
    if (distt > 275&&distt<=600)
        near = enemyShips[myShip.id % enemyShips.length];
    else if (distt > 600) {
      myShip.setSpeed(shipMaxSpeed)

        var goodR = 20;
        var goodRot = 90;

        var p = polarFrom(myShip, { x: 0, y: 0 });

       if(myShip.id%2==0)
           myShip.setRotSpeed((p.rot + goodRot) / dt);
       else
       myShip.setRotSpeed((p.rot - goodRot) / dt);
        near = null;
    }
    return near;
}



function distance(myShip,enemyShip)
{
    var bunmo = Math.sqrt(Math.pow(Math.tan(myShip.shootingRot), 2) + 1);
    return (Math.tan(myShip.shootingRot) * enemyShip.x - enemyShip.y) / bunmo;
}