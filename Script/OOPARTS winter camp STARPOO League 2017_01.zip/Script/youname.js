var mycrew1 = [];
var mycrew2 = [];
var mycrew3 = [];
var mycrew4 = [];
var flag = 0;
var direction =0;
function update() {
    
    if(flag<1){
        mycrew1[0] = myShips[0];
        mycrew1[1] = myShips[1];
        mycrew1[2] = myShips[2];
        mycrew1[3] = myShips[3];
        mycrew2[0] = myShips[4];
        mycrew2[1] = myShips[5];
        mycrew2[2] = myShips[6];
        mycrew2[3] = myShips[7];
        mycrew3[0] = myShips[8];
        mycrew3[1] = myShips[9];
        mycrew3[2] = myShips[10];
        mycrew3[3] = myShips[11];
        mycrew4[0] = myShips[12];
        mycrew4[1] = myShips[13];
        mycrew4[2] = myShips[14];
        mycrew4[3] = myShips[15];
        flag++;
        if (myShips[0].x > 0)
            direction = -1;
        else
            direction = 1;
    }
    
        mycrew1.forEach(function(myShip,index){
            if(enemyShips.length == 0)
                searchEnemy(myShip,index);
            if(myShips<10)
                attackEnemy(myShip);})
    //for (var i = 0; i < mycrew1.length; i++) 
  
    //for (var i = 0; i < mycrew2.length;i++)
    {
        
        if (enemyShips.length == 0)
            rotate1(mycrew2);
        else
            attackEnemy(mycrew2);
    }
    //for (var i = 0; i < mycrew3.length; i++) 
    {
        
        if (enemyShips.length == 0)
            rotate2(mycrew3);
        else
            attackEnemy(mycrew3);
    }
    //for (var i = 0; i < mycrew4.length; i++) 
    {

        if (enemyShips.length == 0)
            backside(mycrew4,direction);
        else
            attackEnemy(mycrew4);
    }
}
function backside(myShip,direction)
{
    var pos1 = polarFrom(myShip[0], { x: direction * -groundRadius * 0.6 / 2, y:direction*groundRadius*0.7/2*Math.sqrt(3) });
    var pos2 = polarFrom(myShip[1], { x: direction * -groundRadius * 0.6 / 2 * Math.sqrt(3), y: direction * groundRadius * 0.7 / 2 });
    var pos3 = polarFrom(myShip[2], { x: direction * -groundRadius * 0.6 / 2, y: direction * -groundRadius * 0.7 / 2 * Math.sqrt(3) });
    var pos4 = polarFrom(myShip[3], { x: direction * -groundRadius * 0.6 / 2 * Math.sqrt(3), y: direction * -groundRadius * 0.7 / 2 });
    if(pos1.r>0.1)
    {
        myShip[0].setRotSpeed(pos1.rot/dt);
        myShip[0].setSpeed(pos1.r/dt);
    }
    else
    {
        myShip[0].setRotSpeed(0);
        myShip[0].setSpeed(0);
    }
    if (pos2.r > 0.1) {
        myShip[1].setRotSpeed(pos2.rot / dt);
        myShip[1].setSpeed(pos2.r / dt);
    }
    else {
        myShip[1].setRotSpeed(0);
        myShip[1].setSpeed(0);
    }
    if (pos3.r > 0.1) {
        myShip[2].setRotSpeed(pos3.rot / dt);
        myShip[2].setSpeed(pos3.r / dt);
    }
    else {
        myShip[2].setRotSpeed(0);
        myShip[2].setSpeed(0);
    }
    if (pos4.r > 0.1) {
        myShip[3].setRotSpeed(pos4.rot / dt);
        myShip[3].setSpeed(pos4.r / dt);
    }
    else {
        myShip[3].setRotSpeed(0);
        myShip[3].setSpeed(0);
    }
}
//function search(myShip,index) {
//   polarFrom(myShip[index],)    
//}
/*function frontside() {
    var pos2 = polarFrom(myShips[1], { x: direction * groundRadius * 0.5 / 2, y: direction * -groundRadius * 0.5 / 2 * Math.sqrt(3) });
    myShips[1].setRotSpeed(pos2.rot / dt);
    myShips[1].setSpeed(pos2.r / dt);
    var pos3 = polarFrom(myShips[2], { x: direction * -groundRadius * 0.5 / 2, y: direction * -groundRadius * 0.5 / 2 * Math.sqrt(3) });
    myShips[2].setRotSpeed(pos3.rot / dt);
    myShips[2].setSpeed(pos3.r / dt);
    var pos1 = { x: myShips[0].x, y: myShips[0].y };
    myShips[0].setRotSpeed(pos1.rot / dt);
    myShips[0].setSpeed(pos1.r / dt);
    var pos4 = { x: myShips[3].x, y: myShips[3].y };
    myShips[3].setRotSpeed(pos4.rot / dt);
    myShips[3].setSpeed(pos4.r / dt);
}*/
/*function backside2(myShip, direction) {
    var pos1 = polarFrom(myShip[0], { x: direction * groundRadius * 0.5 / 2, y: direction * -groundRadius * 0.5 / 2 * Math.sqrt(3) });
    var pos2 = polarFrom(myShip[1], { x: direction * groundRadius * 0.5 / 2 * Math.sqrt(3), y: direction * -groundRadius * 0.5 / 2 });
    var pos3 = polarFrom(myShip[2], { x: direction * groundRadius * 0.5 / 2, y: direction * groundRadius * 0.5 / 2 * Math.sqrt(3) });
    var pos4 = polarFrom(myShip[3], { x: direction * groundRadius * 0.5 / 2 * Math.sqrt(3), y: direction * groundRadius * 0.5 / 2 });
    if (pos1.r > 0.1) {
        myShip[0].setRotSpeed(pos1.rot);
        myShip[0].setSpeed(pos1.r);
    }
    else {
        myShip[0].setRotSpeed(0);
        myShip[0].setSpeed(0);
    }
    if (pos2.r > 0.1) {
        myShip[1].setRotSpeed(pos2.rot);
        myShip[1].setSpeed(pos2.r);
    }
    else {
        myShip[1].setRotSpeed(0);
        myShip[1].setSpeed(0);
    }
    if (pos3.r > 0.1) {
        myShip[2].setRotSpeed(pos3.rot);
        myShip[2].setSpeed(pos3.r);
    }
    else {
        myShip[2].setRotSpeed(0);
        myShip[2].setSpeed(0);
    }
    if (pos4.r > 0.1) {
        myShip[3].setRotSpeed(pos4.rot);
        myShip[3].setSpeed(pos4.r);
    }
    else {
        myShip[3].setRotSpeed(0);
        myShip[3].setSpeed(0);
    }
}*/
function searchEnemy(myShip,index){
    var targetDegree = index * 90 / mycrew1.length;
    var targetR = groundRadius * 0.1;

    var targetPoint = cartesian({r:targetR,rot:targetDegree});
    var polarFromShip = polarFrom(myShip,targetPoint);

    myShip.setRotSpeed(polarFromShip.rot/dt);
    myShip.setSpeed(polarFromShip.r/dt);
}
function attackEnemy(myShip){

	var targetPoint = enemyShips[0];
	
	for (var i = 0; i < myShip.length; i++) {
	    myShip[i].setSpeed(0);

	    var polarFromShip = polarFrom(myShip[i], targetPoint);

	    myShip[i].setRotSpeed(polarFromShip.rot / dt);

	    if (Math.abs(polarFromShip.rot) < 0.01) {
	        myShip[i].shoot(1.25);
	    }
	}
	
}
function rotate1(myShip)
{
   for (var i = 0; i < myShip.length; i++) {
        
        var ship = myShip[i];
        ship.setSpeed(shipMaxSpeed-i*16);

        var goodRot = 90;
        var goodR = 20;

        var p = polarFrom(ship, { x: 0, y: 0 });

        ship.setRotSpeed((p.rot - goodRot) / dt);
    }
}
function rotate2(myShip)
{
    for (var i = 0; i < myShip.length; i++) {
        
        var ship = myShip[i];
        ship.setSpeed(shipMaxSpeed - i*16);

        var goodRot = -90;
        var goodR = 20;

        var p = polarFrom(ship, { x: 0, y: 0 });

        ship.setRotSpeed((p.rot - goodRot) / dt);
    }
}