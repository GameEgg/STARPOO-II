var idle_myShips = [];
var busy_myShips = [];
var free_enemyShips = [];
var targetReports = [];
var b_init = false;
var MAX_GROUND_SIZE;
var BEST_SHOOT_DIST = 600;

var counter = 0;

var Cps = dt * (1.5); // chargedPower per second

// 극딜 & 짤짤이 모드

function update() {
    try {
        if(!b_init){
            b_init = true;
            init();
        }

        // 내 Idle 함선 리스트 업데이트
        updateIdle_myShips();
        
        // 적 함선중 타겟이 되지 않은 함선 업데이트
        updateFree_enemyShips();

        // 전 프레임에서 가지고 있었던 타겟팅 리포트 체크
        reCheckTargetReport();

        // if(free_enemyShips.length > 0)
        //     log(free_enemyShips.length);

        // 노려지지 않은 적 함선에 대해 킬러 함선 매칭
        matchingTarget();

        // 타겟이 정해진 아군함선에 대해 killing protocol 수행
        targetReports.forEach(runKillingProtocol, this);

        // for (var i = 0; i < targetReports.length; i++) {
        //     log(i + " my:" + targetReports[i].myShip.id + ", enemy:" + targetReports[i].enemyShip.id);
        // }

        // 할거없는 잉여 함선에 대해 정찰
        idle_myShips.forEach(moveArround, this);    
    } catch (error) {
        log(error)
        log(error.stack)
    }
}

function init() {
    MAX_GROUND_SIZE = groundRadius;
    myShips.forEach(function(ship, index) {
        // idle_myShips.push(ship);
        // ship.setSpeed();
    }, this);
}

function updateIdle_myShips() {
    // Clean Up idle_myShips Array
    idle_myShips.splice(0, idle_myShips.length);

    myShips.forEach(function(ship, index) {    
        if (!ship.isCharging && !isMyShipExistInTargetReports(targetReports, ship)) {
            idle_myShips.push(ship);
        }
    }, this);
}

function updateFree_enemyShips() {
    var i = 0
    var cursor = 0;
    free_enemyShips.splice(0, free_enemyShips.length);
    
    for (i = 0; i < enemyShips.length; i++) {
        if (cursor != targetReports.length) {
            for (; cursor < targetReports.length; ) {
                if (enemyShips[i].id > targetReports[cursor].enemyShip.id) {
                    cursor++;
                    continue;
                }
                if (enemyShips[i].id < targetReports[cursor].enemyShip.id) {
                    free_enemyShips.push(enemyShips[i]);
                    break;
                }
                else if (enemyShips[i].id == targetReports[cursor].enemyShip.id) {
                    cursor++;
                    break;
                }
                // log("[" + counter++ + "] 5");
            }    
        }
        else {
            free_enemyShips.push(enemyShips[i]);
        }
        // log("[" + counter++ + "] 4");
    }
}

function reCheckTargetReport() {
    for (var i = 0; i < targetReports.length;) {
        var myShip = getShip(myShips, targetReports[i].myShip.id);
        if (myShip == null) {
            targetReports.splice(i, 1);
        }
        // 현재 함선이 보이지 않는데 이미 한번 발사를 한경우 report 에서 drop
        else if (!isExistInArray(free_enemyShips, targetReports[i].enemyShip) && (targetReports[i].tryCount > 0) && !myShip.isCharging) {
            targetReports.splice(i, 1);
        }
        else {
            i++;
        }
        // log("[" + counter++ + "] 6");
    }
}

function movePoint(ship, destination) {
    var pos = polarFrom(ship, destination);

    if (pos.r > 0.1) {
        ship.setSpeed(pos.r / dt)
        ship.setRotSpeed(pos.rot / dt);
    }
    else {
        ship.setRotSpeed(0);
        ship.setSpeed(0);
    }
}

function trackingTarget(ship, destination) {
    var pos = polarFrom(ship, destination);

    if (pos.r > 150) {
        ship.setSpeed(pos.r / dt)
        ship.setRotSpeed(pos.rot / dt);
    }
    else {
        ship.setRotSpeed(0);
        ship.setSpeed(0);
    }
}

function runingOut(ship, target) {
    // var pos = polarFrom(ship, target);

    // if (pos.r > 150) {
    //     ship.setSpeed(pos.r / dt)
    //     ship.setRotSpeed(pos.rot / dt);
    // }
    // else {
        ship.setRotSpeed(0);
        ship.setSpeed(0);
    // }
}

function moveArround(ship, index) {
    var pos = polarFrom(ship, {x: 0, y: 0});
    ship.setSpeed(shipMaxSpeed);

    var destR = groundRadius * (index + 1) / (idle_myShips.length + 1);
    var correctionR = ((pos.r - destR) / groundRadius) * 360;

    if (ship.id % 2 == 0) {
        ship.setRotSpeed((pos.rot - 90 + correctionR) / dt);
    }
    else {
        ship.setRotSpeed((pos.rot + 90 - correctionR) / dt);
    }
}

function getBestAgent(targetShip) {
    var bestAgent = null;
    var bestRot = 180;
    var bestDist = 2 * groundRadius;

    idle_myShips.forEach(function(ship, index) {
         var p = polarFrom(ship, targetShip);
         if (checkSafeShootAngle(ship) && (Math.abs(p.rot) < Math.abs(bestRot))) {
             bestRot = p.rot;
             bestAgent = ship;
         }
    }, this);

    return bestAgent;
}

function checkSafeShootAngle(ship) {
    for(var i = 0; i < myShips.length; i++) {
        if (myShips[i].id != ship.id) {
            var nextPos = {};
            nextPos.x = myShips[i].x + cos(myShips[i].rotSpd * dt) * myShips[i].spd * dt;
            nextPos.y = myShips[i].y + sin(myShips[i].rotSpd * dt) * myShips[i].spd * dt;
            var temp_p = polarFrom(ship, nextPos);

            if (Math.abs(temp_p.rot - ship.shootingRot) < 10)
                return false;
        }
        
        // log("[" + counter++ + "] 1" );
    }
    return true;
}

function matchingTarget() {
    for (var i = 0; i < free_enemyShips.length; ) {
        var bestAgent = getBestAgent(free_enemyShips[i]);
        if (bestAgent != null) {
            var report = {};
            report['myShip'] = bestAgent;
            report['enemyShip'] = free_enemyShips[i];
            report['tryCount'] = 0;
            
            targetReports.push(report);
            busy_myShips.push(bestAgent);
            removeShipInArray(idle_myShips, bestAgent);
            free_enemyShips.splice(i, 1);
        }
        else {
            i++;
        }
        // log("[" + counter++ + "] 3" );
    }
    // TODO : 적함선이 내 함선수보다 작다면 다구리
}

function runKillingProtocol(report, index) {
    var enemyShip = getShip(enemyShips, report.enemyShip.id);
    var myShip = getShip(myShips, report.myShip.id);
    
    // 업데이트 내 함선 상태
    report.myShip = myShip;

    // 적을 찾을수 없는 경우
    if (enemyShip == null) {
        // 가까이 다가가는데 없어져서 그자리까지 갔는데도 못찾은 경우 target report drop
        if (dist(myShip, report.enemyShip) < 0.1) {
            removeShipInArray(busy_myShips, myShip);
            for (var i = 0; i < targetReports.length; i++){
                if(targetReports[i].myShip.id == myShip.id) {
                    targetReports.splice(i, 1);
                    break;
                }
                // log("[" + counter++ + "] 2");
            }
            idle_myShips.push(myShip);
        }
        else {
            movePoint(report.myShip, report.enemyShip);
        }
    }

    // 적이 여전히 Tracking 가능한 경우
    else {
        // 업데이트 타겟 적 함선 상태
        report.enemyShip = enemyShip;
        var distance = dist(report.myShip, report.enemyShip);
        if (report.myShip.isCharging) {
            // TODO : 발사직전에 아군이 있으면 옆에 쏘기
            // 남은 차징 에너지 / 1.5 = 걸리는 초
            // 걸리는 초 / dt = 총 프레임
            // 2*dt*1.5 = 남은 차징에너지
            // 즉 남은 프레임이 2개일 때
            var num_frames = 100;
            if (maxChargingPower - report.myShip.chargedPower < 20 * Cps) {
                // 다음 프레임에 움직일방향을 계산
                var pos = polarFrom(report.myShip, report.enemyShip);
                var expectPosition = {};
                var e_speed = Math.min((pos.r / dt), shipMaxSpeed);
                var e_rotSpeed;
                if ((pos.rot / dt) > 0) {
                    e_rotSpeed = Math.min((pos.rot / dt), 360);
                }
                else {
                    e_rotSpeed = Math.max((pos.rot / dt), -360);
                }
                // expectPosition = calculateNextPosition(report.myShip, e_speed, e_rotSpeed);
                expectPosition = calculateNextPositionWithFrames(report.myShip, e_speed, e_rotSpeed, num_frames);

                // 움직였을때 안전한 각도인지 계산 일어나는지 계산
                if (checkSafeShootAngle(expectPosition)) {
                    runingOut(report.myShip, report.enemyShip);
                }

                // 만약 안전한 각도가 아니라면
                else {
                    // 2 ~ 4 가지 정도 방향으로 움직였을때
                    // 회피 가능성 체크 후,  최대한 적은 각도 변화로 움직이는 것을 목표로 방향 꺾기
                    var b_findGoodEscapeRoot = false;
                    var angles = [360, -360, -180, 180];
                    for (var j = 0; j < angles.length; j++) {
                        var nextPos = {};
                        nextPos.x = report.myShip.x + cos(angles[j] * dt) * report.myShip.spd * dt;
                        nextPos.y = report.myShip.y + sin(angles[j] * dt) * report.myShip.spd * dt;
                        nextPos.rot = report.myShip.rot + angles[j] * dt;
                        nextPos.shootingRot = report.myShip.shootingRot;
                        if (checkSafeShootAngle(nextPos)) {
                            b_findGoodEscapeRoot = true;
                            report.myShip.setSpeed(shipMaxSpeed);
                            report.myShip.setRotSpeed(angles[j]);
                            break;
                        }
                    }
                    
                    if (!b_findGoodEscapeRoot) {
                        report.myShip.setSpeed(0);
                        report.myShip.setRotSpeed(0);
                    }
                }
            }

            // TODO : 상대를 향해 발포각도가 고정됬을때 좌우방향 mirroring moving
            runingOut(report.myShip, report.enemyShip);

        }
        else {
            if (bestShootAngle(report.myShip, report.enemyShip)){
                // if (checkSafeShootAngle(report.myShip, report.enemyShip)) {
                report.tryCount++;
                report.myShip.shoot(maxChargingPower);
                // }
            }
            else {
                trackingTarget(report.myShip, report.enemyShip);
            }
        }
    }
}

function calculateNextPosition(ship, speed, rot) {
    var pos = {};
    pos.x = ship.x + cos(rot * dt) * speed * dt;
    pos.y = ship.y + sin(rot * dt) * speed * dt;
    pos.rot = ship.rot + ship.rotSpd * dt;
    return pos;
}

function calculateNextPositionWithFrames(ship, speed, rot, num_frames) {
    var expectShip = {};
    expectShip.x = ship.x;
    expectShip.y = ship.y;
    expectShip.rot = ship.rot;
    expectShip.rotSpd = ship.rotSpd;
    expectShip.shootingRot = ship.shootingRot;

    for (var i = 0; i < num_frames; i++) {
        expectShip.x = expectShip.x + cos(rot * dt) * speed * dt;
        expectShip.y = expectShip.y + sin(rot * dt) * speed * dt;
        expectShip.rot = expectShip.rot + expectShip.rotSpd * dt;
    }
    
    return expectShip;
}

function bestShootAngle(myShip, enemyShip) {
    var p = polarFrom(myShip, enemyShip);
    if (-1 < p.rot && p.rot < 1) {
        return true;
    }
    return false;
}

function isExistInArray(array, object) {
    for (var i = 0; i < array.length; i++) {
        if (array[i] == object) {
            // array.splice(i, 1);
            return true;
        }
    }
    return false;
}

function isMyShipExistInTargetReports(targetReports, object) {
    for (var i = 0; i < targetReports.length; i++) {
        if (targetReports[i].myShip == object) {
            return true;
        }
    }
    return false;
}

function getShip(ships, id) {
    for (var i = 0; i < ships.length; i++) {
        if (ships[i].id == id) {
            return ships[i];
        }
    }
    return null;
}

function getShipIndex(ships, id) {
    for (var i = 0; i < ships.length; i++) {
        if (ships[i].id == id) {
            return i;
        }
    }
    return -1;
}

function removeShipInArray(array, ship) {
    for (var i = 0; i < array.length; i++) {
        if (array[i].id == ship.id) {
            array.splice(i, 1);
            return;
        }
    }
}