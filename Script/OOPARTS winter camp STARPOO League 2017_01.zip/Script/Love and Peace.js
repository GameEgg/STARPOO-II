var shipradius = 0.8;

//var _enemyShips = [];
/*
for (var i = enemyShips.length - 1; i >= 0; i--) {
    _enemyShips[i] = { id: enemyShips[i].id, count:0}
    }
    */
function update() {
    try {

       /* for (var i = enemyShips.length - 1; i >= 0; i--) {
            _enemyShips[i] = { id: enemyShips[i].id}
        }*/

        for (var i = myShips.length - 1; i >= 0; i--) {
            var myShip = myShips[i];
            if (enemyShips.length == 0) {
                myShip.setSpeed(shipMaxSpeed);
                myShip.setRotSpeed((polarFrom(myShip, { x: 0, y: 0 }).rot - 90) / dt);
                //search(myShip, i);
            }
            else {
                var target = aquire_target(myShip);
                if (target) {
                    tracking(myShip, target);
                    fire(myShip, target);
                }
                else
                    search(myShip, i);
            }
        }
        /*if(){
            fire(myShip,target);
        }*/

        /* if(enemyShips.length == 0)
             search(myship,index);
         else
             attack(myship);*/
    }
        catch (e) {
        log(e);
        log(e.stack);
    }
    }


function get_engage_radius(ship,target) {
    var _dist = dist(ship,target) //�Ÿ����ϱ�
    var rad = Math.asin( shipradius / _dist ) // �Ÿ��� ��ũ�������� ų�����ϱ�
    var deg = r2d(rad) // ���� ���� ��ȯ
    return deg //��������

} //�Լ��� ��ǥ���� ������ ��ȿ������ ���ϱ�
/*
function myship_is_locked_on(ship) {
    var e_ship;
    for (var i = enemyShips.length - 1; i >= 0; i--) {
        e_ship = enemyShips[i];
        rad = polarFrom(e_ship, ship)
        if (Math.abs(rad.rot) < get_engage_radius(e_ship, ship))
            return true
    }
}

function enemyship_is_locked_on(ship) {
    var e_ship;
    for (var i = myShips.length - 1; i >= 0; i--) {
        e_ship = myShips[i];
        rad = polarFrom(e_ship, ship)
        if (Math.abs(rad.rot) < get_engage_radius(e_ship, ship) && ship.isCharging)
            return true
    }
}
*/
    
function search(myShip, i) {
    var targetDegree = i * 360 / myShips.length;
    var targetR = groundRadius * 0.70;
    var targetPoint = cartesian({ r: targetR, rot: targetDegree });
    var polarFromShip = polarFrom(myShip, targetPoint);

    myShip.setRotSpeed(polarFromShip.rot / dt);
    myShip.setSpeed(polarFromShip.r / dt);
}



function tracking(myShip, target) {
    var res = polarFrom(myShip, target);
        if (Math.abs(res.rot) >= 10) {
            myShip.setSpeed(0);
            myShip.setRotSpeed(shipMaxRotSpeed);
        }
        else if (Math.abs(res.rot) < 10) {
            myShip.setSpeed(shipMaxSpeed);
            // myShip.setRotSpeed(-res.rot);
            if (dist(myShip,target)<50)
                myShip.setSpeed(0);
        }
    

}

function aquire_target(myShip){
    var current, min, e_ship, _target, _count;
    _count=0;
    min = 999999;
    _target = false;
    for(var i=0;i<enemyShips.length;i++){
        e_ship = enemyShips[i];
        current = dist(myShip,e_ship);
        if(current<min){
            min = current;
            if (/*_enemyShips[i].count>2*/iscrowded(e_ship) !=true /*enemyship_is_locked_on!=true*/) {
                _target = e_ship;
              
            }
        }
        
    }
    return _target;
}

function fire(myShip, target) {
    

        //myShip.setSpeed(0/*shipMaxSpeed/2*/);
        //var target = enemyShips[0]; //���� ó�� �߰��� ��
        var polarFromShip = polarFrom(myShip, target);
        myShip.setRotSpeed(polarFromShip.rot / dt);

        if (Math.abs(polarFromShip.rot) < get_engage_radius(myShip, target)) {
            if(dist(myShip,target)<50)
                myShip.shoot(Math.min(shipMaxHp / 5, target.hp));
            else if(dist(myShip,target)<500)
                myShip.shoot(Math.min(shipMaxHp / 20, target.hp));
        }
    
    
}

function iscrowded(enemyShip){

    
    var count = 0;
    for(var i=0;i<myShips.length;i++){
        var myShip = myShips[i];
        if(dist(myShip,enemyShip)<300){
            count++;
        }
    }
    if(count>3)
        return true
    else
        false
}

/*function fire(myShip, target) {
    if (dist(myShip, target) < 0.5) {
        myShip.setSpeed = 0;
        myShip.shoot(2);
    }
    else
        myShip.shoot(0.5);
}*/
