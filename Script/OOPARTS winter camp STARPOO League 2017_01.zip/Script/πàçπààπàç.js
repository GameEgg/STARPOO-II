// JavaScript source code

var frameCount = 0;
var isMovingForward = false;
var isArranging = true;
var isLeftSide;
var prevGroundRadius = groundRadius;

var detectPos, detectedPrev = false;
var detectID;
var posDiff;

var targetR;

var isReady = false;

var foundTime;
var forwardRate = 0;

var shootTime = 3.1111 * dt;

var myShipsStable = [];
var shipCount;
function update() {

    if (frameCount == 0) {
        if (myShips[0].x < 0)
            isLeftSide = true;
        else
            isLeftSide = false;

        myShips.forEach(function (myShip, index) {
            myShipsStable[index] = { id: myShip.id, index: index };
        });

    }

    else {

        if (shipCount != myShips.length) {
            var i, j;

            for (i = 0; i < shipCount; i++) {
                var isDestroyed = true;
                for (j = 0; j < myShips.length; j++) {
                    if (myShipsStable[i].id == myShips[j].id)
                    {
                        isDestroyed = false;
                        break;
                    }
                }
                        
                if(isDestroyed)
                {
                    for(var k = i; k < shipCount - 1; k++)
                        myShipsStable[k] = myShipsStable[k + 1];
                    i--; shipCount--; continue;
                }
            }
        }
    }

    shipCount = myShips.length;
    frameCount++;

    targetR = groundRadius * 0.6;

    if (myShips.length == 1)
    {
        log("AAAAAA");
        moveTo(myShips[0], 0, 0);
        if (polar(myShips[0]).r < 1)
            myShips[0].shoot(shipMaxHp / 2);
        if (myShips[0].isDetected)
            attackEnemy(myShips[0], shipMaxHp / 2);
        return;
    }


    if (enemyShips.length != 0) {
        isReady = false;
        /*foundTime = frameCount;
        if (!detectedPrev) {
            detectedPrev = true;
            detectPos = { x: enemyShips[0].x, y: enemyShips[0].y };
            detectID = enemyShips[0].id;
        }

        else {
            myShips.forEach(function (myShip, index) {
                var i;
                for (i = 0; i < enemyShips.length; i++) {
                    if (enemyShips[i].id == detectID) {
                        posDiff = { x: enemyShips[i].x - detectPos.x, y: enemyShips[i].y - detectPos.y };
                        attackEnemy(myShip, { x: (enemyShips[i].x + posDiff.x) * shootTime, y: (enemyShips[i].y + posDiff.y) * shootTime });
                    }
                }
            });
            detectedPrev = false;
        }
        */
        myShips.forEach(function (myShip, index) {

            if (myShip.isDetected && !myShip.isCharging) {
                var min = polarFrom(myShip, enemyShips[0]);

                for (var i = 1; i < enemyShips.length; i++)
                    if (polarFrom(myShip, enemyShips[i]).r < min)
                        min = polarFrom(myShip, enemyShips[i]);
                /*
                if(Math.abs((polarFrom({x:myShip.x, y:myShip.y, rot:min.rot + 90}, {x:0, y:0}).rot)) < Math.abs((polarFrom({x:myShip.x, y:myShip.y, rot:min.rot - 90}, {x:0, y:0}).rot))) {
                    myShip.setRotSpeed(polarFrom({x:myShip.x, y:myShip.y, rot:min.rot + 90}, {x:0, y:0}).rot / dt);
                    myShip.setSpeed(shipMaxSpeed);
                    log("CCW");
                }
                else {
                    myShip.setRotSpeed(polarFrom({ x: myShip.x, y: myShip.y, rot: min.rot - 90 }, { x: 0, y: 0 }).rot / dt);
                    myShip.setSpeed(shipMaxSpeed);
                    log("CW");
                }
                *//*
                if (myShip.id == myShipsStable[myShips.length - 1].id) {
                    var str = "";
                    str += frameCount;
                    str += " x: " + myShip.x + ", y: " + myShip.y;
                    log(str);
                }*/
                //var pos = { x: 2 * myShip.x - cartesian(min).x, y: 2 * myShip.y - cartesian(min).y };
                if (myShips.length % 2 == 0 && myShip.id == myShipsStable[myShips.length - 1].id) {
                    var targetPoint = { x: 0, y: 50 };
                    moveTo(myShip, targetPoint.x, targetPoint.y);
                    if(polarFrom(targetPoint, myShip).r < 3)
                        attackEnemy(myShip, shipMaxHp / 3);
                    //log("last one");
                    return;
                }
                var pos;
                var polarpos = polar(myShip);
                polarpos.r = groundRadius * 0.92;
                /*
                if (polarpos.r > groundRadius * 0.92)
                    polarpos.r = groundRadius * 0.92;
                */pos = cartesian(polarpos);

                if (polarFrom(myShip, pos).r > 3)
                    moveTo(myShip, pos.x, pos.y);
                else
                    attackEnemy(myShip, shipMaxHp / 3);



            }
            else if (polarFrom(myShip, enemyShips[0]).r > 700)
                Arrange(myShip, index);
            else
                attackEnemy(myShip, shipMaxHp/3);
        });
        isArranging = false;
    }

    if (isArranging) {
        //log("Arranging");
        isReady = true;
        myShips.forEach(function (myShip, index) {

            Arrange(myShip, index);
        });
        if (isReady == true)
            isArranging = false;
    }

    else if (isReady == true) {
        //log("A");
        isArranging = false;
        //forwardRate = forwardRate + (isLeftSide ? 1 : -1);

        myShips.forEach(function (myShip, index) {

            if (polarFrom(myShip, { x: 0, y: 0 }).r > groundRadius * 0.8)
                isArranging = true;
            myShip.shoot(shipMaxHp);
            
        });
        /*
        if (forwardRate > groundRadius * 0.5) {
            isLeftSide = false;
            forwardRate = 0;
        }
        else if (forwardRate < -groundRadius * 0.5) {
            isLeftSide = true;
            forwardRate = 0;
        }*/
    }

    else {
        isArranging = true;
        //log("else");
    }
    prevGroundRadius = groundRadius;
}

function Arrange(myShip, index) {
    
    var centerPoint = { r: targetR, rot: isLeftSide ? 180 : 0 };
    var centerPointD = cartesian(centerPoint);
    var nDivision = Math.floor((myShips.length - 1) / 2);

    var targetPoint;

    shipNum = findShipNum(myShip);

    if (shipNum < nDivision) {
        var upPoint = { r: targetR * 1.25, rot: isLeftSide ? 120 : 60 };
        var upPointD = cartesian(upPoint);

        targetPoint = { x: upPointD.x - ((upPointD.x - centerPointD.x) / nDivision * shipNum) + forwardRate, y: upPointD.y - ((upPointD.y - centerPointD.y) / nDivision * shipNum) };
    }
    else if(nDivision != 0){
        var downPoint = { r: targetR * 1.25, rot: isLeftSide ? 240 : 300 };
        var downPointD = cartesian(downPoint);

        targetPoint = { x: centerPointD.x + ((downPointD.x - centerPointD.x) / nDivision * (shipNum - nDivision)) + forwardRate, y: centerPointD.y + ((downPointD.y - centerPointD.y) / nDivision * (shipNum - nDivision)) };
    }
    else {
        targetPoint = { x: centerPointD.x, y: centerPointD.y };
    }
    
    var polarFromShip;

    //log("myShip = " + myShip.id + ", last one: " + myShipsStable[myShips.length - 1].id);
    /*if (myShip.id == myShipsStable[myShips.length - 1].id) {
        var str = "";
        str += frameCount;
        str += " x: " + myShip.x + ", y: " + myShip.y;
        log(str);
    }*/
    if (myShips.length % 2 == 0 && myShip.id == myShipsStable[myShips.length - 1].id) {
        targetPoint = { x: 0, y: 50 };
        polarFromShip = polarFrom(myShip, targetPoint);
        //log("last one_2");
    }
    else
        polarFromShip = polarFrom(myShip, targetPoint);

    if (polarFrom(myShip, targetPoint).r < 10) {
        myShip.setSpeed(0);
        if (Math.abs(polarFrom(myShip, { x: (isLeftSide ? 10000000 : -10000000), y: 0 }).rot) > 1) {
            isReady = false;
            //log("B");
            myShip.setRotSpeed((isLeftSide ? -myShip.rot : ((180 - Math.abs(myShip.rot)) * (myShip.rot > 0 ? 1 : -1))) / dt);
            //log(myShip.rot);
            //log((isLeftSide ? -myShip.rot : ((180 - Math.abs(myShip.rot)) * (myShip.rot > 0 ? 1 : -1))));
        }
        else {
            myShip.setRotSpeed(0);
            myShip.shoot(shipMaxHp);
        }
        
    }
    else {
        isReady = false;
        myShip.setRotSpeed(polarFromShip.rot / dt);
        if (Math.abs(polarFromShip.rot) < 10)
            myShip.setSpeed(polarFromShip.r / dt/* * polarFrom(myShip, targetPoint).r / 300*/);

        //log("C");
    }
}

function attackEnemy(myShip, damage) {
    //log("A");
    myShip.setSpeed(0);

    var targetPoint = enemyShips[0];
    var polarFromShip = polarFrom(myShip, targetPoint);
    myShip.setRotSpeed(polarFromShip.rot / dt);

    if (Math.abs(polarFromShip.rot) < 1) {
        //log("B");
        myShip.shoot(damage);
    }

    
}

function moveTo(myShip, x, y) {
    var targetPoint = { x: x, y: y };
    var polarFromShip = polarFrom(myShip, targetPoint);

    if (myShips.length == 1)
        log("rot: " + JSON.stringify(myShip));

    if ( polar(myShip).rot > 0 && polarFromShip.rot > 0 || (polar(myShip).rot < 0 && polarFromShip.rot < 0))
        polarFromShip.rot = -polarFromShip.rot;
    log("polarFromShip.rot = " + polarFromShip.rot);

    myShip.setRotSpeed(polarFromShip.rot / dt);

    if (Math.abs(polarFromShip.rot) < 10)
        myShip.setSpeed(polarFromShip.r / dt);
    else
        myShip.setSpeed(0);
}

function findShipNum(myShip)
{
    for (var i = 0; i < shipCount; i++)
        if (myShipsStable[i].id == myShip.id)
            return i;
}