var totalTime = 0;
var SHIP_R_safe = 35;
var SHIP_R_target = 15;
var POWER = 0.2;
var POWER_not_detected = 0.4;
var zero = vec(0,0);
var STATES = {};


function updateMyShip(ship,i)
{
	if(ship.isCharging){
		ship.setSpeed(0);
		ship.setRotSpeed(0);
		return;
	}
	var power = computeShootable(ship);
	if(power > 0 && ship.delay === 0)
	{
		ship.setSpeed(0);
		ship.setRotSpeed(0);
		ship.shoot(power);
	}
	else
	{
		if(enemyShips.length === 0)
		{
			if(i == 0)
				freeMove(ship);
			else if(attackGoodTarget(ship)){

			}
			else
				moveAndShootAsSniper(ship,i);
		}
		else
		{
			if(ship.isDetected && ship.delay == 0){
				attackGoodTarget(ship);
			}
			else{
				if(i == 0)
					freeMove(ship);
				else
					moveAndShootAsSniper(ship,i);
			}
		}
	}
}

function sign(n){
	return n < 0 ? -1 : 1;
}

function normalizeRot(rot){
	rot%=360;
	if(rot < -180)
		rot += 360;
	else if(rot > 180)
		rot -= 360;
	return rot;
}

function moveAndShootAsSniper(ship,i){
	try{
		var myPolar = polarFrom(ship,zero);
		targetRot = 360*i/myShips.length-180;
		var targetRotDist = normalizeRot(targetRot - polar(ship).rot);
		var rrr;
		if(myPolar.r < groundRadius*0.85)
			rrr = 120;
		else
			rrr = (myPolar.r < groundRadius*0.9) ? 95 : 70;

		var condzero1 = myPolar.r > groundRadius*0.92 && Math.abs(myPolar.rot) > 92;
		var condzero2 = myPolar.r < groundRadius*0.8 && Math.abs(myPolar.rot) < 85;
		if(Math.abs(targetRotDist) < 5 && myPolar.r > groundRadius*0.9){
			attackGoodTarget(ship);
		}
		else if(condzero1 || condzero2){
			ship.setSpeed(0);
			ship.setRotSpeed((myPolar.rot+rrr * sign(-targetRotDist))/dt);
		}
		else{
			ship.setSpeed(shipMaxSpeed);
			ship.setRotSpeed((myPolar.rot+rrr * sign(-targetRotDist))/dt);
		}
	}
	catch(e){
		log("moveAndShootAsSniper-----------------!"+e);
	}
}

function lookEnemy(ship,p,range){
	ship.setSpeed(0);
	if(ship.rotSpd >= 0 && p.rot < -range){
		ship.setRotSpeed(-shipMaxRotSpeed*0.7);
		
	}
	else if(ship.rotSpd <= 0 && p.rot > range){
		ship.setRotSpeed(shipMaxRotSpeed*0.7);
		
	}
	else if(Math.abs(ship.rotSpd) < shipMaxRotSpeed * 0.4){
		ship.setRotSpeed(shipMaxRotSpeed*sign(p.rot)*0.7);
	}
}

function findNearestEnemy(ship){
	if(enemyShips.length == 0) return null;

	var minP = null;
	var minShip;
	for(var i = 0; i < enemyShips.length; ++i){
		var enemy = enemyShips[i];
		var p = polarFrom(ship,enemy);
		if(minP === null){
			minP = p;
			continue;
		}
		var d = p.rot*0.5+p.r;
		if(d < minP.rot*0.5+minP.r){
			minP = p;
			minShip = enemy;
		}
	}
	return minShip;
}

function attackGoodTarget(ship)
{
	var nearestEnemy = findNearestEnemy(ship);
	if(nearestEnemy == null)
		return false;

	ship.setRotSpeed(polarFrom(ship,nearestEnemy).rot/dt);
	var power = computeShootable(ship);
	if(power > 0){
		ship.shoot(power);
		return true;
	}
	return false;
}

function freeMove(ship)
{
	if(ship.nextPos === undefined || dist(ship,ship.nextPos) < shipMaxSpeed*dt || ship.nextPosDur > 1.2)
	{
		ship.nextPos = cartesian({r:random()*groundRadius*0.9,rot:360*random()});
		ship.nextPosDur = 0;
		if(polar(ship.nextPos).r > groundRadius*0.9)
		{
			ship.nextPos = undefined;
			freeMove(ship);
			return;
		}
	}

	var p = polarFrom(ship,ship.nextPos);
	var pzero = polarFrom(ship,zero);
	if(Math.abs(pzero.rot) > 89 && pzero.r > groundRadius * 0.93){
		ship.setSpeed(0);
	}
	else{
		ship.setSpeed(p.r/dt);
	}
	ship.nextPosDur += dt;
	ship.setRotSpeed(p.rot/dt);

}


function computeShootable(ship){
	if(ship.delay > 0) 
		return 0;
	for(var i = 0; i < enemyShips.length;++i){
		var enemy = enemyShips[i];
		var future = futurePosEnemy(enemy,POWER/chargingSpeed);
		var power = (ship.isDetected) ? POWER : POWER_not_detected;
		if(future === null){
			power = 0;
		}
		if(enemy.isCharging){
			var chargingDur = (enemy.shootingPower-enemy.chargedPower);
			power += chargingDur;
			if(future === null)
				future = enemy;
		}
		if(future === null)
			continue;
		var polarFuture = polarFrom(ship,future);
		if((Math.abs(polarFuture.rot) < 60) && (sin(Math.abs(polarFuture.rot))*polarFuture.r < SHIP_R_target)){
			if(checkSafeShootable(ship,power/chargingSpeed)){
				return power;
			}
		}
	}
	return 0;
}

function checkSafeShootable(ship,t){
	for(var i = 0; i < myShips.length;++i){
		var mine = myShips[i];
		if(mine.id == ship.id)
			continue;

		var future = futurePosMine(mine,t);
		var polarFuture = polarFrom(ship,future);
		if((Math.abs(polarFuture.rot) < 70) && (sin(Math.abs(polarFuture.rot))*polarFuture.r < SHIP_R_safe))
		{
			return false;
		}
	}
	return true;
}

function llog(ship,i,str){
	if(myShips[i] !== null){
		if(ship.id == myShips[i].id){
			log(str);
		}
	}
}


function futurePosMine(ship,t)
{
	var middleR = (ship.rot + ship.rotSpd*t)*0.5;
	var dx = cos(middleR)*ship.spd*t;
	var dy = sin(middleR)*ship.spd*t;


	return vec(ship.x+dx,ship.y+dy);
}

function futurePosEnemy(ship,t){

	var prev = EnemyHistory.get(ship.id);
	if(prev !== null){
		var dx = ship.x-prev.x;
		var dy = ship.y-prev.y;
		var rotSpd = (ship.rot-prev.rot)/dt;
		var spd = dist(zero,vec(dx,dy))/dt;
		var futureR = ship.rot + rotSpd*t;

		var futureX = 0;
		var futureY = 0;
		var virtualR = ship.rot;

		for(var i = 0; i < t; i +=dt){
			virtualR += rotSpd*dt;
			futureX += cos(virtualR)*spd*dt;
			futureY += sin(virtualR)*spd*dt;
		}
		futureX += 2*cos((virtualR+ship.rot)/2)*spd*dt;
		futureY += 2*sin((virtualR+ship.rot)/2)*spd*dt;
		return vec(ship.x+futureX,ship.y+futureY);
	}
	else{
		return null;
	}
	
}

function vec(x,y){
	return {x:x,y:y};
}


function shootEnemy(){

}

var EnemyHistory = {
	history:[],
	update:function()
	{
		for(var i = 0; i < enemyShips.length; ++i){
			var enemy = enemyShips[i];
			var hist = null;
			for(var j = 0; j < this.history.length; ++j){
				var checkingItem = this.history[j];
				if(checkingItem.id == enemy.id){
					hist = checkingItem;
				}
			}
			if(hist === null){
				hist = {id:enemy.id,x:enemy.x,y:enemy.y,rot:enemy.rot,t:totalTime};
				this.history.push(hist);
			}
			else{
				hist.x = enemy.x;
				hist.y = enemy.y;
				hist.rot = enemy.rot;
				hist.t = totalTime;
			}
		}
	},
	get:function(id){
		for(var j = 0; j < this.history.length; ++j){
			var checkingItem = this.history[j];
			if(checkingItem.id == id){
				if(checkingItem.t >= totalTime-dt*1.5){
					return checkingItem;
				}
				else{
					return null;
				}
			}
		}
		return null;
	}
};

var Finder = {
	getMyShip:function(id){
		for(var i = 0; i < myShips.length; ++i){
			if(myShips[i].id == id){
				return myShips[id];
			}
		}
	},
	getEnemyShip:function(id){
		for(var i = 0; i < enemyShips.length; ++i){
			if(enemyShips[i].id == id){
				return enemyShips[id];
			}
		}
	}
};



var goodTargets = [];

function settingGoodTargets()
{
	var tmpEnemies = [];
	goodTargets.length = 0;
	enemyShips.forEach(function(enemy){
		enemy.dist = 0;
		for(var i = 0; i < myShips.length; ++i){
			var mine = myShips[i];
			enemy.dist += dist(mine,enemy);
		}
		tmpEnemies.push(enemy);
	});
	while(goodTargets.length < enemyShips.length){
		var goodIndex = 0;
		var removedIndex = -1;
		tmpEnemies.forEach(function(enemy,i){
			if(enemy == null) 
				return;
			if(goodTargets[goodIndex] == null)
			{
				goodTargets[goodIndex] = enemy;
				return;
			}
			if(goodTargets[goodIndex].dist > enemy.idst)
			{
				goodTargets[goodIndex] = enemy;
				removedIndex = i;
			}
			
			tmpEnemies[removedIndex] = null;
			goodIndex++;
		});
	}

}

function update()
{
	totalTime += dt;//업뎃 1줄 고정
	settingGoodTargets();

	myShips.forEach(updateMyShip);

	EnemyHistory.update();//마지막
}