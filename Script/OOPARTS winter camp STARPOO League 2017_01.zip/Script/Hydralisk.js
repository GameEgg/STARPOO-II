var chargetime=0.117
var chargetime2=0.0878
var minchargetime=chargetime
var maxchargetime=chargetime*2.5
var maxShips=myShips.length
var enemydmg=-1
var shipradian=15.0*0.1
var gametime=0

var blackconstant=40
var redconstant=60
var orangeconstant=80
var yellowconstant=120
var shotconstant=30
var friendlyshotconstant=42

var locationstop=groundRadius*0.99
var locationveryverydanger=groundRadius*0.97
var locationverydanger=groundRadius*0.85
var locationdanger=groundRadius*0.7
var frienddistance=groundRadius*0.5
var enemydistance=groundRadius*0.15
var soloplay=5
var enemydmgconstant=1

var flag=1//flag변수

var counttime=0

function update(){
	setenemydmg()
	valupdate()
	
	var enemylist=[]
	var targetlist=[]
	
	setenemylist(enemylist)
	settargetlist(targetlist, enemylist)
	if(enemyShips.length!=0)
		counttime=0
	for (var i=0;i<myShips.length;i++) {
		
		flag++
		
		var ship = myShips[i]
		ship.setSpeed(shipMaxSpeed)
		ship.setRotSpeed(0)
		if(enemyShips.length==0){
			if(counttime<7)
				racon(ship)
			else if(myShips.length==1)
				racon(ship)
			else
				rotatearoundcenter(ship, i)
		}
		else{
			var blackcount=0
			var redcount=0
			var orangecount=0
			var yellowcount=0
			
			for(var j=0;j<enemyShips.length;j++){
				var enemy=enemyShips[j]
				if(enemy.isCharging){
					var vdist=getverticaldistancefromenemy(enemy, ship)
					if(vdist<blackconstant)
						blackcount++
					if(vdist<redconstant)
						redcount++
					if(vdist<orangeconstant)
						orangecount++
					if(vdist<yellowconstant)
						yellowcount++
					
				}
			}
			if(blackcount!=0)
				inblack(ship)
			else if(redcount!=0){
				inred(ship)
			}
			else if(orangecount!=0){
				inorange(ship)
			}
			else if(yellowcount!=0){
				inyellow(ship)
			}
			else if(enemydmg<0)
				ingreenlargedmg(ship, targetlist[i])
			else if(enemydmg<enemydmgconstant)
				ingreensmalldmg(ship)
			else 
				ingreenlargedmg(ship, targetlist[i])
		}
	}
}

function setenemylist(enemylist){
	if(enemyShips.length!=0){
		enemylist[0]=enemyShips[0]
		for(var i=1;i<enemyShips.length;i++){
			var farenemy=enemyShips[i-1]
			var edist=0
			
			for(var j=0;j<enemyShips.length;j++){
				var isinlist=0
				for(var k=0;k<enemylist.length;k++){
					if(enemylist[k].id==enemyShips[j].id){
						isinlist=1
						break
					}
				}
				if(isinlist==0){
					var tdist=dist(enemylist[i-1], enemyShips[j])
					if(tdist>edist){
						edist=tdist
						farenemy=enemyShips[j]
					}
				}
			}
			enemylist[i]=farenemy
		}
	}
}

function settargetlist(targetlist, enemylist){
	for(var i=0;i<myShips.length;i++){
		targetlist[i]=null
	}
	for(var i=0;i<enemylist.length;i++){
		if(i==myShips.lentgh)
			break
		var mdist=99999999
		var closestfriend=-1
		for(var j=0;j<myShips.length;j++){
			if(targetlist[j]==null){
				var tdist=dist(myShips[j], enemylist[i])
				if(tdist=mdist){
					mdist=tdist
					closestfriend=j
				}
			}
		}
		if(closestfriend!=-1)
			targetlist[closestfriend]=enemylist[i]
	}
}

function setenemydmg(){
	for(var i=0;i<enemyShips.length;i++){
		eship=enemyShips[i]
		if(eship.isCharging){
			var chargeval=eship.shootingPower
			if(enemydmg<0)
				enemydmg=chargeval
			else if(chargeval>enemydmg)
				enemydmg=chargeval
		}
	}
}

function valupdate(){
	locationstop=groundRadius*0.98
	locationveryverydanger=groundRadius*0.96
	locationverydanger=groundRadius*0.85
	locationdanger=groundRadius*0.7
	frienddistance=groundRadius*2
	enemydistance=groundRadius*0.5
	soloplay=5
	counttime+=dt
}



function getverticaldistancefromally(shooter, target, calculateback){
	var tpolarfrom=polarFrom(shooter, target)
	var rot=tpolarfrom.rot
	var r=tpolarfrom.r
	
	if(rot<0){
		rot=-rot
	}
	if(rot>90){
		if(calculateback==0)
			return 9999999
		else
			return r
	}
	var rdist=r*sin(rot)
	return rdist
}

function getverticaldistancefromenemy(shooter, target){
	
	var tpolarfrom=polarFrom(shooter, target)
	var rot=tpolarfrom.rot
	var r=tpolarfrom.r
	
	var angle=tpolarfrom.rot-shooter.shootingRot+shooter.rot
	
	if(angle<0){
		angle=-angle
	}
	
	var rdist=r*sin(angle)
	return rdist
}


function getplusminusshootingangle(shooter, target){
	var tpolar=polarFrom(shooter, target)
	var angle=tpolar.rot-shooter.shootingRot+shooter.rot
	
	var rot3=shooter.shootingRot
	var thrower=rot3-target.rot
	
	thrower=sin(thrower)
	if(thrower<0)
		thrower=-thrower
	if(thrower<sin(0))
		return -1
	else if(sin(angle)*sin(rot3-target.rot)<0)
		return 1
	else
		return -1
}

function shootfunc(ship, target){
	var canshoot=0
	var friendlyfirenarrow=0
	var friendlyfirewide=0
	if(getverticaldistancefromally(ship, target, 0)<shotconstant){
		var ttr1=polarFrom(target, ship)
		var ttr2=polarFrom(ship, target)
		if(ttr1.rot*ttr2.rot<0){
			canshoot=1
		}
	}
	if(canshoot==1){
		var thischargetime=minchargetime
		var enemychargelefttime=target.shootingPower-target.chargedPower
		if(enemychargelefttime<minchargetime)
			thischargetime=minchargetime
		else if(enemychargelefttime>maxchargetime)
			thischargetime=maxchargetime
		else
			thischargetime=enemychargelefttime
		for(var i=0;i<myShips.length;i++){
			if(ship.id!=myShips[i].id){
				var vdist=getverticaldistancefromally(ship, myShips[i], 1)
				if(vdist<friendlyshotconstant){
					friendlyfirenarrow=1
					break
				}
				else if(vdist<yellowconstant){
					friendlyfirewide=1
				}
			}
		}
		if(friendlyfirenarrow==0){
			if(friendlyfirewide==0){
				if(ship.delay==0)
					ship.shoot(thischargetime)
			}
			else{
				if(ship.delay==0)
					ship.shoot(minchargetime)
			}
		}
	}
}

function shootfunc2(ship, target){
	var canshoot=0
	var friendlyfirenarrow=0
	if(getverticaldistancefromally(ship, target, 0)<shotconstant){
		var ttr1=polarFrom(target, ship)
		var ttr2=polarFrom(ship, target)
		if(ttr1.rot*ttr2.rot<0){
			canshoot=1
		}
	}
	if(canshoot==1){
		var thischargetime=minchargetime
		
		for(var i=0;i<myShips.length;i++){
			if(ship.id!=myShips[i].id){
				var vdist=getverticaldistancefromally(ship, myShips[i], 1)
				if(vdist<friendlyshotconstant){
					friendlyfirenarrow=1
					break
				}
			}
		}
		if(friendlyfirenarrow==0){
			if(ship.delay==0)
				ship.shoot(minchargetime)
		}
	}
}

function rotatearoundcenter(ship, i){
	var goodr=groundRadius
	goodr=goodr*i/myShips.length
	var goodRot=90
	var polarfrom=polarFrom(ship, {x:0,y:0})
	var pr=polarfrom.r
	var prot=polarfrom.rot
	
	ship.setSpeed(shipMaxSpeed)
	
	if(pr<goodr){
		if(prot<0)
			if(prot<-100*(1-(goodr-pr)/groundRadius))
				ship.setRotSpeed(-shipMaxRotSpeed)
			else
				ship.setRotSpeed(shipMaxRotSpeed)
		else
			if(prot>100*(1-(goodr-pr)/groundRadius))
				ship.setRotSpeed(shipMaxRotSpeed)
			else
				ship.setRotSpeed(-shipMaxRotSpeed)
	}
	else{
		if(prot<0){
			if(prot<-75*(1-(pr-goodr)/groundRadius))
				ship.setRotSpeed(-shipMaxRotSpeed)
			else
				ship.setRotSpeed(shipMaxRotSpeed)
		}
		else{
			if(prot>75*(1-(pr-goodr)/groundRadius))
				ship.setRotSpeed(shipMaxRotSpeed)
			else
				ship.setRotSpeed(-shipMaxRotSpeed)
		}
	}
}

function racon(ship){
	var friend=myShips[0]
	var fdistance=9999999
	ship.setSpeed(shipMaxSpeed)
	ship.setRotSpeed(0)
	var turnright=-1
	var turnleft=1
	var tpolar2=polarFrom(ship, {x:0,y:0})
	var myr=tpolar2.r
	var myrot=tpolar2.rot
	if(myShips.length!=1){
		if(myr>locationverydanger){
			if(myrot<0){
				ship.setRotSpeed(-shipMaxRotSpeed)
			}
			else{
				ship.setRotSpeed(shipMaxRotSpeed)
			}
		}
		else{
			var fx=0.0
			var fy=0.0
			var ftan=0.0
			for(var i=0;i<myShips.length;i++){
				if(ship.id!=myShips[i].id){
					var tdist=dist(ship, myShips[i])
					if(tdist<fdistance){
						fdistance=tdist
						friend=myShips[i]
					}
					if(tdist<frienddistance){
						fx+=(ship.x-myShips[i].x)/tdist
						fy+=(ship.y-myShips[i].y)/tdist
					}
				}
			}
			if(fx<0){
				if(fy<0){
					if(sin(ship.rot)<0){
						if(cos(ship.rot)<0){
							ftan=fy/fx
							var ttan=sin(ship.rot)/cos(ship.rot)
							if(ftan>ttan){
								ship.setRotSpeed(shipMaxRotSpeed)
							}
							else{
								ship.setRotSpeed(-shipMaxRotSpeed)
							}
						}
						else{
							ship.setRotSpeed(-shipMaxRotSpeed)
						}
					}
					else{
						if(cos(ship.rot)<0){
							ship.setRotSpeed(shipMaxRotSpeed)
						}
						else{
							ftan=fy/fx
							var ttan=sin(ship.rot)
							if(cos(ship.rot)==0){
								ttan=ttan/0.000001
							}
							else{
								ttan=ttan/cos(ship.rot)
							}
							if(ftan>ttan){
								ship.setRotSpeed(-shipMaxRotSpeed)
							}
							else{
								ship.setRotSpeed(shipMaxRotSpeed)
							}
						}
					}
				}
				else{
					if(sin(ship.rot)<0){
						if(cos(ship.rot)<0){
							ship.setRotSpeed(-shipMaxRotSpeed)
						}
						else{
							ftan=fy/fx
							var ttan=sin(ship.rot)
							if(cos(ship.rot)==0){
								ttan=ttan/0.000001
							}
							else{
								ttan=ttan/cos(ship.rot)
							}
							if(ftan>ttan){
								ship.setRotSpeed(-shipMaxRotSpeed)
							}
							else{
								ship.setRotSpeed(shipMaxRotSpeed)
							}
						}
					}
					else{
						if(cos(ship.rot)<0){
							ftan=fy/fx
							var ttan=sin(ship.rot)
							if(cos(ship.rot)==0){
								ttan=ttan/0.000001
							}
							else{
								ttan=ttan/cos(ship.rot)
							}
							if(ftan>ttan){
								ship.setRotSpeed(shipMaxRotSpeed)
							}
							else{
								ship.setRotSpeed(-shipMaxRotSpeed)
							}
						}
						else{
							ship.setRotSpeed(shipMaxRotSpeed)
						}
					}
				}
			}
			else{
				if(fx==0)
					fx=0.000001
				if(fy<0){
					if(sin(ship.rot)<0){
						if(cos(ship.rot)<0){
							ship.setRotSpeed(shipMaxRotSpeed)
						}
						else{
							ftan=fy/fx
							var ttan=sin(ship.rot)
							if(cos(ship.rot)==0){
								ttan=ttan/0.000001
							}
							else{
								ttan=ttan/cos(ship.rot)
							}
							if(ftan>ttan){
								ship.setRotSpeed(shipMaxRotSpeed)
							}
							else{
								ship.setRotSpeed(-shipMaxRotSpeed)
							}
						}
					}
					else{
						if(cos(ship.rot)<0){
							ftan=fy/fx
							var ttan=sin(ship.rot)
							if(cos(ship.rot)==0){
								ttan=ttan/0.000001
							}
							else{
								ttan=ttan/cos(ship.rot)
							}
							if(ftan>ttan){
								ship.setRotSpeed(-shipMaxRotSpeed)
							}
							else{
								ship.setRotSpeed(shipMaxRotSpeed)
							}
						}
						else{
							ship.setRotSpeed(-shipMaxRotSpeed)
						}
					}
				}
				else{
					if(sin(ship.rot)<0){
						if(cos(ship.rot)<0){
							ftan=fy/fx
							var ttan=sin(ship.rot)
							if(cos(ship.rot)==0){
								ttan=ttan/0.000001
							}
							else{
								ttan=ttan/cos(ship.rot)
							}
							if(ftan>ttan){
								ship.setRotSpeed(-shipMaxRotSpeed)
							}
							else{
								ship.setRotSpeed(shipMaxRotSpeed)
							}
						}
						else{
							ship.setRotSpeed(shipMaxRotSpeed)
						}
					}
					else{
						if(cos(ship.rot)<0){
							ship.setRotSpeed(-shipMaxRotSpeed)
						}
						else{
							ftan=fy/fx
							var ttan=sin(ship.rot)
							if(cos(ship.rot)==0){
								ttan=ttan/0.000001
							}
							else{
								ttan=ttan/cos(ship.rot)
							}
							if(ftan>ttan){
								ship.setRotSpeed(shipMaxRotSpeed)
							}
							else{
								ship.setRotSpeed(-shipMaxRotSpeed)
							}
						}
					}
				}
			}
		}
	}
	else{
		if(myr>soloplay){
			if(myrot<-45){
				ship.setRotSpeed(-shipMaxRotSpeed)
			}
			else if(myrot>45){
				ship.setRotSpeed(shipMaxRotSpeed)
			}
			else{
				ship.setRotSpeed(0)
			}
		}
	}
}

function ingreensmalldmg(ship){
	var shootanything=0
	var enemy=enemyShips[0]
	var edistance=99999999
	var tpolar2=polarFrom(ship, {x:0,y:0})
	var myr=tpolar2.r
	var myrot=tpolar2.rot
	var isenemy=0
	var friend=myShips[0]
	var fdistance=9999999
	if(myShips.length!=1){
		if(myr>locationverydanger){
			if(myrot<0){
				ship.setRotSpeed(-shipMaxRotSpeed)
			}
			else{
				ship.setRotSpeed(shipMaxRotSpeed)
			}
			shootanything=1
		}
		else{
			for(var i=0;i<enemyShips.length;i++){
				var tdist=dist(ship, enemyShips[i])
				if(tdist<edistance){
					edistance=tdist
					enemy=enemyShips[i]
				}
			}
			
			for(var i=0;i<myShips.length;i++){
				if(ship.id!=myShips[i].id){
					var tdist=dist(ship, myShips[i])
					if(tdist<fdistance){
						fdistance=tdist
						friend=myShips[i]
					}
				}
			}
			if(edistance<enemydistance*0.3){
				var fpolar=polarFrom(ship, enemy)
				var fr=fpolar.r
				var frot=fpolar.rot
				if(frot<0){
					if(edistance<enemydistance*0.3)
						ship.setRotSpeed(shipMaxRotSpeed)
				}
				else{
					if(edistance<enemydistance*0.3)
						ship.setRotSpeed(-shipMaxRotSpeed)
				}
				shootanything=1
				isenemy=1
			}
			else if(fdistance<frienddistance){
				var iamclosest=1
				for(var i=0;i<myShips.length;i++){
					if(dist(ship, enemy)>dist(myShips[i], enemy)){
						iamclosest=0
						break
					}
				}
				
				if(iamclosest==1){
					var fpolar=polarFrom(ship, enemy)
					var fr=fpolar.r
					var frot=fpolar.rot
					if(frot<0){
						ship.setRotSpeed(-shipMaxRotSpeed)
					}
					else{
						ship.setRotSpeed(shipMaxRotSpeed)
					}
					shootanything=1
					isenemy=1
				}
				else{
					var fpolar=polarFrom(ship, friend)
					var fr=fpolar.r
					var frot=fpolar.rot
					if(frot<0){
						
							ship.setRotSpeed(shipMaxRotSpeed)
					}
					else{
						
							ship.setRotSpeed(-shipMaxRotSpeed)
					}
					isenemy=1
					shootanything=1
				}
			}
			else{
				ship.setRotSpeed(0)
			}
		}
	}
	else{
		if(myr>soloplay){
			if(myrot<-135){
				ship.setRotSpeed(-shipMaxRotSpeed)
			}
			else if(myrot>135){
				ship.setRotSpeed(shipMaxRotSpeed)
			}
			else{
				ship.setRotSpeed(0)
			}
		}
		shootanything=1
	}
	
	var target=enemyShips[0]
	if(shootanything==1){
		var tdistance=999999999
		for(var i=0;i<enemyShips.length;i++){
			var ttdist=getverticaldistancefromally(ship, enemyShips[i], 0)
			if(ttdist<tdistance){
				tdistance=ttdist
				target=enemyShips[i]
			}
		}
	}
	else{
		var hpcount=9999
		for(var i=0;i<enemyShips.length;i++){
			if(enemyShips[i].hp<hpcount){
				hpcount=enemyShips[i].hp
				target=enemyShips[i]
			}
		}
		var po=polarFrom(ship, target)
		if(isenemy==0){
		if(po.rot<0)
			ship.setRotSpeed(-shipMaxRotSpeed)
		else
			ship.setRotSpeed(shipMaxRotSpeed)
		}
		
	}
	
	if(!ship.isCharging){
		shootfunc(ship, target)
	}
}

function ingreenlargedmg(ship, target22){
	var shootanything=0
	var enemy=enemyShips[0]
	var edistance=99999999
	var tpolar2=polarFrom(ship, {x:0,y:0})
	var myr=tpolar2.r
	var myrot=tpolar2.rot
	var isenemy=0
	var friend=myShips[0]
	var fdistance=9999999
	if(myShips.length!=1){
		if(myr>locationverydanger){
			if(myrot<0){
				ship.setRotSpeed(-shipMaxRotSpeed)
			}
			else{
				ship.setRotSpeed(shipMaxRotSpeed)
			}
			shootanything=1
		}
		else{
			for(var i=0;i<enemyShips.length;i++){
				var tdist=dist(ship, enemyShips[i])
				if(tdist<edistance){
					edistance=tdist
					enemy=enemyShips[i]
				}
			}
			
			for(var i=0;i<myShips.length;i++){
				if(ship.id!=myShips[i].id){
					var tdist=dist(ship, myShips[i])
					if(tdist<fdistance){
						fdistance=tdist
						friend=myShips[i]
					}
				}
			}
			if(target22!=null){
				var fpolar=polarFrom(ship, target22)
				var fr=fpolar.r
				var frot=fpolar.rot
			
				if(frot<0)
					ship.setRotSpeed(-shipMaxRotSpeed)
				else
					ship.setRotSpeed(shipMaxRotSpeed)
			}
			else if(edistance<enemydistance*0.3){
				var fpolar=polarFrom(ship, enemy)
				var fr=fpolar.r
				var frot=fpolar.rot
				if(frot<0){
					if(edistance<enemydistance*0.3)
						ship.setRotSpeed(shipMaxRotSpeed)
				}
				else{
					if(edistance<enemydistance*0.3)
						ship.setRotSpeed(-shipMaxRotSpeed)
				}
				shootanything=1
				isenemy=1
			}
			else if(fdistance<frienddistance){
				var fpolar=polarFrom(ship, friend)
				var fr=fpolar.r
				var frot=fpolar.rot
				if(frot<0){
					
						ship.setRotSpeed(shipMaxRotSpeed)
				}
				else{
					
						ship.setRotSpeed(-shipMaxRotSpeed)
				}
				isenemy=1
				shootanything=1
			}
			else{
				ship.setRotSpeed(0)
			}
		}
	}
	else{
		if(myr>soloplay){
			if(myrot<-135){
				ship.setRotSpeed(-shipMaxRotSpeed)
			}
			else if(myrot>135){
				ship.setRotSpeed(shipMaxRotSpeed)
			}
			else{
				ship.setRotSpeed(0)
			}
		}
		shootanything=1
	}
	
	var target=enemyShips[0]
	if(shootanything==1){
		var tdistance=999999999
		for(var i=0;i<enemyShips.length;i++){
			var ttdist=getverticaldistancefromally(ship, enemyShips[i], 0)
			if(ttdist<tdistance){
				tdistance=ttdist
				target=enemyShips[i]
			}
		}
	}
	else{
		var hpcount=9999
		for(var i=0;i<enemyShips.length;i++){
			if(enemyShips[i].hp<hpcount){
				hpcount=enemyShips[i].hp
				target=enemyShips[i]
			}
		}
		var asdfff
		if(target22==null)
			asdfff=target
		else
			asdfff=target22
		var po=polarFrom(ship, asdfff)
		if(isenemy==0){
		if(po.rot<0)
			ship.setRotSpeed(-shipMaxRotSpeed)
		else
			ship.setRotSpeed(shipMaxRotSpeed)
		}
		
	}
	
	if(!ship.isCharging){
		shootfunc(ship, target)
	}
	ship.setSpeed(shipMaxSpeed)
}

function inblack(ship){
	var target=enemyShips[0]
	var chargelefttime=999999999
	var target2=enemyShips[0]
	var enemydist=999999999
	for(var i=0;i<enemyShips.length;i++){
		if(enemyShips[i].isCharging){
			if(getverticaldistancefromenemy(enemyShips[i], ship)<blackconstant){
				var tchargelefttime=enemyShips[i].shootingPower-enemyShips[i].chargedPower
				if(tchargelefttime<chargelefttime){
					chargelefttime=tchargelefttime
					target=enemyShips[i]
				}
				var tenemydist=dist(ship, enemyShips[i])
				if(tenemydist<enemydist){
					enemydist=tenemydist
					target2=enemyShips[i]
				}
			}
		}
	}
	
	var trot=target.shootingRot-ship.rot
	
	
	var tpolar2=polarFrom(ship, {x:0,y:0})
	if(tpolar2.r>locationveryverydanger){
		ship.setSpeed(0)
		if(tpolar2.rot<-80){
			ship.setRotSpeed(-shipMaxRotSpeed)
		}
		else if(tpolar2.rot>80){
			ship.setRotSpeed(shipMaxRotSpeed)
		}
		else{
			if(tpolar2.r<locationstop){
				ship.setSpeed(shipMaxSpeed)
			}
		}
	}
	else{
		if(sin(trot)*cos(trot)<0)
			ship.setRotSpeed(shipMaxRotSpeed)
		else
			ship.setRotSpeed(-shipMaxRotSpeed)
		
		ship.setSpeed(shipMaxSpeed)
	}
	
}

function inred(ship){
	var target=enemyShips[0]
	var chargelefttime=999999999
	var target2=enemyShips[0]
	var enemydist=999999999
	for(var i=0;i<enemyShips.length;i++){
		if(enemyShips[i].isCharging){
			if(getverticaldistancefromenemy(enemyShips[i], ship)<redconstant){
				var tchargelefttime=enemyShips[i].shootingPower-enemyShips[i].chargedPower
				if(tchargelefttime<chargelefttime){
					chargelefttime=tchargelefttime
					target=enemyShips[i]
				}
				var tenemydist=dist(ship, enemyShips[i])
				if(tenemydist<enemydist){
					enemydist=tenemydist
					target2=enemyShips[i]
				}
			}
		}
	}
	
	var trot=target.shootingRot-ship.rot
	
	
	var tpolar2=polarFrom(ship, {x:0,y:0})
	if(tpolar2.r>locationveryverydanger){
		ship.setSpeed(0)
		if(tpolar2.rot<-80){
			ship.setRotSpeed(-shipMaxRotSpeed)
		}
		else if(tpolar2.rot>80){
			ship.setRotSpeed(shipMaxRotSpeed)
		}
		else{
			if(tpolar2.r<locationstop){
				ship.setSpeed(shipMaxSpeed)
			}
		}
	}
	else if(enemydist<(redconstant+blackconstant)/2){
		var tpolar3=polarFrom(ship, target2)
		var tr3=tpolar3.r
		var trot3=tpolar3.rot
		if(tpolar3.rot<-80)
			ship.setSpeed(shipMaxSpeed)
		else if(tpolar3.rot>80)
			ship.setSpeed(shipMaxSpeed)
		else
			ship.setSpeed(0)
		if(tpolar3.rot<0)
			ship.setRotSpeed(shipMaxRotSpeed)
		else{
			ship.setRotSpeed(-shipMaxRotSpeed)
		}
		ship.setSpeed(shipMaxSpeed)
	}
	else{
		if(sin(trot)*cos(trot)<0)
			ship.setRotSpeed(shipMaxRotSpeed)
		else
			ship.setRotSpeed(-shipMaxRotSpeed)
		var chargelefttime=target.shootingPower-target.chargedPower
		chargelefttime/=1.6
		if(chargelefttime*shipMaxSpeed<(redconstant+blackconstant)*0.6)
			ship.setSpeed(0)
		else 
			ship.setSpeed(shipMaxSpeed)
	}
	
}

function inorange(ship){
	var target=enemyShips[0]
	var orangecount=0
	var orangedistance=99999
	var target2=enemyShips[0]
	var enemydist=999999999
	for(var i=0;i<enemyShips.length;i++){
		if(enemyShips[i].isCharging){
			var torangedistance=getverticaldistancefromenemy(enemyShips[i], ship)
			if(torangedistance<orangeconstant){
				orangecount++
				if(torangedistance<orangedistance){
					orangedistance=torangedistance
					target=enemyShips[i]
				}
			}
			var tenemydist=dist(ship, enemyShips[i])
			if(tenemydist<enemydist){
				enemydist=tenemydist
				target2=enemyShips[i]
			}
		}
	}
	var trot=target.shootingRot-ship.rot	
	
	var tpolar=polarFrom(target, ship)
	var angle=tpolar.rot-target.shootingRot+target.rot

	var tpolar2=polarFrom(ship, {x:0,y:0})
	
	
	if(tpolar2.r>locationveryverydanger){
		ship.setSpeed(0)
		if(tpolar2.rot<-80){
			ship.setRotSpeed(-shipMaxRotSpeed)
		}
		else if(tpolar2.rot>80){
			ship.setRotSpeed(shipMaxRotSpeed)
		}
		else{
			if(tpolar2.r<locationstop){
				ship.setSpeed(shipMaxSpeed)
			}
		}
	}
	else if(getplusminusshootingangle(target, ship)<0){
		ship.setSpeed(0)
		if(sin(angle)*cos(trot)>0){
			
			ship.setRotSpeed(shipMaxRotSpeed)
		}
		else
			ship.setRotSpeed(-shipMaxRotSpeed)
	}
	else{
		ship.setSpeed(0)
		
		if(orangecount==1){
			if(tpolar2.r<locationveryverydanger){
				ship.setSpeed(shipMaxSpeed)
			}
			else if(tpolar2.r<locationstop)
				ship.setSpeed(shipMaxSpeed)
		}
		if(sin(trot)*cos(trot)<0)
			ship.setRotSpeed(shipMaxRotSpeed)
		else
			ship.setRotSpeed(-shipMaxRotSpeed)
	}
}

function inyellow(ship){
	var target=enemyShips[0]
	var target2=enemyShips[0]
	var yellowdistance=99999
	var yellowshotdistance=999999999
	
	var target3=enemyShips[0]
	var enemydist=999999999
	for(var i=0;i<enemyShips.length;i++){
		if(enemyShips[i].isCharging){
			var tyellowdistance=getverticaldistancefromenemy(enemyShips[i], ship)
			var tyellowshotdistance=getverticaldistancefromally(ship, enemyShips[i], 0)
			if(tyellowdistance<yellowconstant){
				if(tyellowdistance<yellowdistance){
					yellowdistance=tyellowdistance
					target=enemyShips[i]
				}
			}
			if(tyellowshotdistance<yellowshotdistance){
				yellowshotdistance=tyellowshotdistance
				target2=enemyShips[i]
			}
			
			var tenemydist=dist(ship, enemyShips[i])
			if(tenemydist<enemydist){
				enemydist=tenemydist
				target3=enemyShips[i]
			}
		}
	}
	if(!ship.isCharging)
		shootfunc2(ship, target2)

	
	
	var trot=target.shootingRot-ship.rot	
	
	var tpolar=polarFrom(target, ship)
	var angle=tpolar.rot-target.shootingRot+target.rot

	var tpolar2=polarFrom(ship, {x:0,y:0})
	
	
	ship.setSpeed(0)
	if(tpolar2.r>locationveryverydanger){
		ship.setSpeed(0)
		if(tpolar2.rot<-80){
			ship.setRotSpeed(-shipMaxRotSpeed)
		}
		else if(tpolar2.rot>80){
			ship.setRotSpeed(shipMaxRotSpeed)
		}
		else{
			if(tpolar2.r<locationstop){
				ship.setSpeed(shipMaxSpeed)
			}
		}
	}
	else if(getplusminusshootingangle(target, ship)<0){
		ship.setSpeed(0)
		if(sin(angle)*cos(trot)>0){
			ship.setRotSpeed(shipMaxRotSpeed)
		}
		else
			ship.setRotSpeed(-shipMaxRotSpeed)
	}
	else{
		ship.setSpeed(0)
		if(sin(trot)*cos(trot)<0)
			ship.setRotSpeed(shipMaxRotSpeed)
		else
			ship.setRotSpeed(-shipMaxRotSpeed)
		if(sin(trot)>sin(80)){
			
			ship.setSpeed(shipMaxSpeed)
		}
		else if(sin(trot)<sin(-80)){
			
			ship.setSpeed(shipMaxSpeed)
		}
	}
}