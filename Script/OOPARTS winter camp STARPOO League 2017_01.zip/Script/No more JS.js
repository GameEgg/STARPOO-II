// Constant Value
var EXPLORER_RATIO = 1;
var STATUS_NORMAL = 0;
var STATUS_INBOUNDARY = 1;
var STATUS_EVADING = 2;
var STATUS_RETURN = 3;
var STATUS_RETURNING = 4;
var STATUS_CHASING = 5;
var STATUS_ESCAPE = 6;
var STATUS_CHARGING = 7;
var STATUS_STOP = 8;
// Global Val
var initialized = false;
var ShipNum;
var controlTower;
var testBool = true;

// Tracking Data
function classEnemyTrackingData(paramID, paramShip){
	this.id = paramID;
	this.enemyShip = paramShip;
	this.isInSight = true;
	this.isAlloc = false;
	this.allocedID = -1;
	this.counter =0;
	// var pos -> tracking 2 pos.
}

classEnemyTrackingData.prototype.SetUpForThisFrame = function(){
	this.isInSight = false;
	this.enemyShip = null;
};

classEnemyTrackingData.prototype.Update = function(paramShip){
	this.isInSight = true;
	this.enemyShip = paramShip;
};

//
// classControlTower
//
function classControlTower(){
		this.EnemyListByID = {};
}

classControlTower.prototype.update = function(){
		// Initialize arr data
		for(var key in this.EnemyListByID)
		{
			this.EnemyListByID[key].SetUpForThisFrame();
		}
		
		for(var i = 0; i<enemyShips.length;++i)
		{
			var enemyShip = enemyShips[i];
			if(!(enemyShip.id in this.EnemyListByID))	// first encount
			{
				this.EnemyListByID[enemyShip.id] = new classEnemyTrackingData(enemyShip.id,enemyShip);
			}
			else{	// encounting
				this.EnemyListByID[enemyShip.id].Update(enemyShip);
			}
		}
};

classControlTower.prototype.findNearestEnemy = function(myShip){
	var min  = 100000;
	var ret = null;
	for(var key in this.EnemyListByID)
	{
		var enemyData = this.EnemyListByID[key];
		if(enemyData.isInSight == false)
			continue;
		var enemyShip = this.EnemyListByID[key].enemyShip;
		var distance = dist(myShip,enemyShip);
		if(distance<min)
		{
			min = distance;
			ret = key;
		}
	}
	return ret;
};

classControlTower.prototype.allocEnemy = function(myShip, key){
	// setup enemyData
	var data = this.EnemyListByID[key];
	data.isAlloc = true;
	data.allocedID = myShip.id;
};

classControlTower.prototype.queryAlloc = function(id){
	return this.EnemyListByID[id].isAlloc;
};

classControlTower.prototype.queryDmg = function(enemyTrackingData,myShip){
	var targetHP = enemyTrackingData.enemyShip.hp;
	if(targetHP>shipMaxHp/2)
	{
		targetHP = targetHP/2;
	}
	return targetHP;
};

function getRandomDir(){
	for(var i = random();i>0;--i);
	
	if(random()<0.5)
		return 1;
	else
		return -1;
}

function reverseDir(dir){
	
}

function update(){

	if(!initialized)
	{
		initialized = true;
		controlTower = new classControlTower();

		ShipNum = myShips.length;
		log("Initialized start");
		
		// Job Alloc
		var ExplorerNum = parseInt(ShipNum*EXPLORER_RATIO);
		myShips.forEach(function(myShip,index){
			var pos = polarFrom(myShip,{x:0,y:0});
			myShip.prevR = pos.r;
			myShip.shipStatus = STATUS_NORMAL;
			myShip.dir = 1;
			myShip.ChasingEnemyID=-1;
			myShip.counter = 0;
 			if(index < ExplorerNum){
				myShip.update = function()
				{
					var pos = polarFrom(this,{x:0,y:0});
					
					if(groundRadius-100 < pos.r && (this.shipStatus!=STATUS_RETURN))
					{
						this.shipStatus = STATUS_RETURN;
					}
					switch(this.shipStatus){
						case STATUS_NORMAL:
						this.setRotSpeed(180*getRandomDir());
						this.setSpeed(shipMaxSpeed);
						if(groundRadius-300<pos.r)
							this.shipStatus = STATUS_INBOUNDARY;
						if(enemyShips.length !=0)
						{
							this.counter+=dt;
							if(this.counter > 0.4)
							{
								this.shipStatus = STATUS_STOP;
								this.counter=0;
								this.setSpeed=0;
							}
							else
							{
								var enemyID = controlTower.findNearestEnemy(this);
								var enemyShipData = controlTower.EnemyListByID[enemyID];

							enemyPos = polarFrom(this,enemyShipData.enemyShip);
							this.setRotSpeed(enemyPos.rot/dt);
							if(Math.abs(enemyPos.rot)<0.01)
							{
								this.setSpeed(0);
								this.shoot(controlTower.queryDmg(enemyShipData,this));
								this.shipStatus = STATUS_CHARGING;
							}
							}
						}
						this.counter = 0;
						break;
						case STATUS_INBOUNDARY:
						if(this.prevR < pos.r)
							this.setRotSpeed(180);
						if(groundRadius - 280 > pos.r)
						{
							this.shipStatus = STATUS_NORMAL;
							this.setRotSpeed(0);
						}
						break;
						case STATUS_RETURN:
						this.setSpeed(0);
						this.setRotSpeed(pos.rot / dt);
						
						if(pos.rot <1)
						{
							this.setSpeed(shipMaxSpeed);
							this.setRotSpeed(0);
						}
						if(pos.r < 50)
						{
							this.shipStatus = STATUS_NORMAL;
						}
						break;
						case STATUS_CHARGING:
						this.setSpeed(0);
						if(enemyShips.length !=0)
						{
							var enemyID = controlTower.findNearestEnemy(this);
							var enemyShipData = controlTower.EnemyListByID[enemyID];
							enemyPos = polarFrom(this,enemyShipData.enemyShip);
							var targetRot = enemyPos.rot - 180;
							this.setRotSpeed(targetRot/dt);;									
						}
						if(this.delay == 0)
							this.shipStatus = STATUS_NORMAL;
						break;
						case STATUS_STOP:
						log("stop");
						this.setSpeed(0);
						this.counter+=dt;
						
						if(enemyShips.length !=0)
						{
							this.setSpeed(0);
							var enemyID = controlTower.findNearestEnemy(this);
							var enemyShipData = controlTower.EnemyListByID[enemyID];
							enemyPos = polarFrom(this,enemyShipData.enemyShip);
							var targetRot = enemyPos.rot;
							this.setRotSpeed(targetRot/dt);
							if(Math.abs(enemyPos.rot)<0.01)
							{
								this.setSpeed(0);
								this.shoot(controlTower.queryDmg(enemyShipData,this));
								this.shipStatus = STATUS_CHARGING;
							}							
						}
						if(this.counter>0)
						{
							this.counter = 0;
							this.shipStatus = STATUS_NORMAL;
						}
						if(this.delay == 0)
							this.shipStatus = STATUS_NORMAL;						
						else
							this.shipStatus = STATUS_NORMAL;
						break;
						case STATUS_ESCAPE:
						
						break;
					}
					this.prevR = pos.r;
				}
				// myShip.onLost = funcion()
				// {

				// };
			}
			else{
				myShip.update = function()
				{
					this.setSpeed(shipMaxSpeed/2);
					var pos = polarFrom(this,{x:0,y:0});
					if(groundRadius - shipMaxSpeed < pos.r)
					{
						this.setSpeed(shipMaxSpeed);
						this.setRotSpeed(180);
					}
					else 
					{
						this.setRotSpeed(0);
					}
					if(enemyShips.length!=0)
					{
						if(this.isDetected)
						{
							this.setSpeed(shipMaxSpeed);
							this.setRotSpeed(180);
						}
					}					
				}
			}
		});
	}
	
	controlTower.update();
	
	myShips.forEach(function(myShip,index)
	{
		myShip.update();
	});
	
}