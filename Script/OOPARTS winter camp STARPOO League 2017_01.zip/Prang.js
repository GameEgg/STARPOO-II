function getCenter() {
    var x = 0;
    var y = 0;
    for (var i = myShips.length - 1; i >= 0; i--) {
        var ship = myShips[i];
        x += ship.x;
        y += ship.y;
    }
    x /= myShips.length;
    y /= myShips.length;
    return { x: x, y: y };
}
function Find() {
    for (var i = myShips.length - 1; i >= 0; i--) {
        var p = polarFrom(myShips[i], getCenter())
        myShips[i].setAngleSpeed(p.angle + 180)
        myShips[i].setSpeed(5)
        var p2 = polarFrom(myShips[i], { x: 0, y: 0 })
        if (p2.r >= groundRadius - 10)
            myShips[i].setSpeed(0)
    }
}

function update() {
    for (var i = myShips.length - 1; i >= 0; i--) {
        if (enemyShips.length == 0) {
            var p = polarFrom(myShips[i], getCenter())
            myShips[i].setAngleSpeed(p.angle + 180)
            myShips[i].setSpeed(5)
           // myShips[i].shoot()
            var p2 = polarFrom(myShips[i], { x: 0, y: 0 })
            if (p2.r >= groundRadius - 3) {
                myShips[i].setSpeed(0)
                myShips[i].setAngleSpeed(p2.angle)
                myShips[i].setSpeed(5)
            }
             //   myShips[i].shoot()
           
        }
        else {
            var p3 = polarFrom(myShips[i], enemyShips[0])
            myShips[i].setAngleSpeed(p3.angle)
            myShips[i].setSpeed(5)
            var p2 = polarFrom(myShips[i], { x: 0, y: 0 })
            myShips[i].shoot()
            if (p2.r >= groundRadius - 3)
                myShips[i].setSpeed(0)
                myShips[i].shoot()


        }
        

      //      if(enemyShips.length!=0){              
      //        var p3 = polarFrom(myShips[i],enemyShips[0])
       //       myShips[i].setAngleSpeed(p3.angle)
     //   }
      //   myShips[i].setAngleSpeed(0)
           
            

    }   
}