function getangle(x, y){
  var angle = Math.atan(y/x);
  var setplus;

  if(x>=0) setplus = r2d(angle);
  else setplus = r2d(Math.PI+angle);
  if(setplus > 180) setplus -=360;

  return setplus;
}

function update(){
  var rand = random()*360;
  for (var i = 0; i < myShips.length; i++) {

    var ship = myShips[i];
    var isshoot = 0;
    var num = 0;

    ship.setSpeed(5);
    ship.setAngleSpeed(-30);

    if(polarFrom(ship,{x:0,y:0}).r > 2/3*groundRadius){
      ship.setAngleSpeed(polarFrom(ship,{x:0,y:0}).angle);
      ship.setSpeed(1);
    }
    else{
      ship.setAngleSpeed(rand);
      ship.setSpeed(5);
    }

    while(enemyShips[num] != null){
      var subangle = getangle(enemyShips[num].x - ship.x , enemyShips[num].y - ship.y );
      var hitangle = subangle - ship.angle;
      if(Math.abs(hitangle) < 10){
        isshoot = 1;
      }
      num++;
    }

    for(var j = 0; j < myShips.length; j++){
      if(i == j) continue;
        var subangle = getangle(myShips[j].x - ship.x , myShips[j].y - ship.y );
        var hitangle = subangle - ship.angle;
        if(Math.abs(hitangle) < 15){
          isshoot = 0;
        }
    }//check ally

    if (isshoot == 1) {
      ship.shoot();
    }
  }
}
