function getEnemyCenter(){
	var x = 0;
	var y = 0;
	for (var i = enemyShips.length - 1; i >= 0; i--) {
		var ship = enemyShips[i];
		x += ship.x;
		y += ship.y;
	}
	x /= enemyShips.length;
	y /= enemyShips.length;
	return {x:x,y:y};
}

function getCenter(){
	var x = 0;
	var y = 0;
	for (var i = myShips.length - 1; i >= 0; i--) {
		var ship = myShips[i];
		x += ship.x;
		y += ship.y;
	}
	x /= myShips.length;
	y /= myShips.length;
	return {x:x,y:y};
}

function translate( ship, destination ){
	var res = polarFrom( ship, destination )
	if(res.angle > 0){
		ship.setAngleSpeed(180)
	}
	if(res.angle < 0){
		ship.setAngleSpeed(-180)
	}
	ship.setSpeed((180 - Math.abs(res.angle)) / 180 * 5)
}

function isTeamKill( id ){
	for(var i = 0; i < allyShips.length; i++){
		if(i == id)
			continue
		var res = polarFrom( allyShips[id], allyShips[i] )
		
		if(Math.abs(res.angle) < getKillAngleSize( allyShips[id], allyShips[i] ))
			return true;
	}
	return false;
}

var shipRadius = 0.7
function getKillAngleSize( shipFrom, shipTo ){
	var distance = dist(shipFrom, shipTo)
	var rad = Math.asin( shipRadius / distance )
	var deg = r2d(rad)
	return deg
}

function isAttackable( attacker, target ){
	var res = polarFrom( attacker, target )
	var warnRange = getKillAngleSize( attacker, target )
	
	if( Math.abs(res.angle) < warnRange )
		return { result : true, pola : res}
	else
		return { result : false, pola : res}
}

function isPosSimilar( a, b ){
	if(dist(a, b) < 3){
		return true;
	}
	else{
		return false;
	}
}

var isRotationPosUpdated = true;
var rotationPos = getCenter();
var rotationPolar = polarFrom({x : 0, y : 0, angle : 0}, rotationPos);

function update(){
	
	if(!isRotationPosUpdated){
		var nextAng = rotationPolar.angle + 30;
		var radius = rotationPolar.r;
		rotationPos = {x : radius * cos(nextAng), y : radius * sin(nextAng)};
		rotationPolar = polarFrom({x : 0, y : 0, angle : 0}, rotationPos);
		isRotationPosUpdated = true;
	}
	
	if(isPosSimilar(getCenter(), rotationPos)){
		isRotationPosUpdated = false;
	}

	if(enemyShips.length == 0){
		for(var i = 0; i < myShips.length; i++){
			
			var escapeVector = { x : 0, y : 0 };
			var isWarned = false;
			
			for(var j = 0; j < bullets.length; j++){
				var attack = isAttackable(bullets[j], myShips[i]);
				
				if(attack.result){
					var isWarned = true;
					var ang = bullets[j].angle;
					
					if(attack.pola.angle < 0){
						ang -= 90;
					}else if(attack.pola.angle > 0){
						ang += 90;
					}
					
					escapeVector.x += cos(ang);
					escapeVector.y += sin(ang);
				}
			}
			
			escapeVector.x += myShips[i].x;
			escapeVector.y += myShips[i].y;
			
			if(isWarned){
				translate(myShips[i], escapeVector);
			}else{
				translate(myShips[i], rotationPos);
			}
			
		}
	}
	else{
		for(var i = 0; i < myShips.length; i++){
			var escapeVector = { x : 0, y : 0 };
			var isWarned = false;
			var isNotTeamKiller = isTeamKill(i);
			
			for(var j = 0; j < enemyShips.length; j++){
				var attack = isAttackable(enemyShips[j], myShips[i]);
				if(attack.result){
					isWarned = true;
					var ang = enemyShips[j].angle;
					
					if(attack.pola.angle < 0){
						ang -= 90;
					}else if(attack.pola.angle > 0){
						ang += 90;
					}
					
					escapeVector.x += cos(ang);
					escapeVector.y += sin(ang);
				}
				
				if(!isNotTeamKiller){
					if(isAttackable(myShips[i], enemyShips[j]).result){
						myShips[i].shoot();
						break;
					}
				}
			}
			
			for(var j = 0; j < bullets.length; j++){
				var attack = isAttackable(bullets[j], myShips[i]);
				if(attack.result){
					isWarned = true;
					var ang = bullets[j].angle;
					
					if(attack.pola.angle < 0){
						ang -= 90;
					}else if(attack.pola.angle > 0){
						ang += 90;
					}
					
					escapeVector.x += cos(ang);
					escapeVector.y += sin(ang);
				}
			}
			
			escapeVector.x += myShips[i].x;
			escapeVector.y += myShips[i].y;
			
			if(isWarned){
				translate(myShips[i], escapeVector);
			}else{
				var center = getEnemyCenter();
				translate(myShips[i], center);
			}
			
		}
	}
}