function getCenter(){
	var x = 0;
	var y = 0;
	for (var i = myShips.length - 1; i >= 0; i--) {
		var ship = myShips[i];
		x += ship.x;
		y += ship.y;
	}
	x /= myShips.length;
	y /= myShips.length;
	return {x:x,y:y};
}
function translate( ship, destination ) {
   var res = polarFrom( ship, destination )
   ship.setAngleSpeed(res.angle)
   ship.setSpeed((180 - Math.abs(res.angle)) / 180 * 5)
}

	var state = 0;
	var shot = 0;

function update(){

for (var i = myShips.length - 1; i >= 0; i--) {
	var ship = myShips[i]			

	if( enemyShips.length > 1)	state = 4
	else if( enemyShips.length <= 1 && enemyShips.length > 0) state = 3
	else if( polarFrom( ship,{x:0,y:0} ).r <=  groundRadius -5 )
		state = 1
	else 	state = 0

	if (state == 0) {
		translate( ship, getCenter() )
		ship.setSpeed(5)
	}
	else if(state == 1) {
		
		if(i >= (myShips.length-1) / 2 )	ship.setAngleSpeed(360)
		else 					ship.setAngleSpeed(-360)	
		if( 360/myShips.length *i <= 180 &&
		    360/myShips.length *i -5 <= ship.angle  &&
		    360/myShips.length *i +5 >= ship.angle
		){
			ship.setSpeed(5)
			ship.setAngleSpeed(0)
		}
		if( 360/myShips.length *i > 180 &&
		    360/myShips.length *i -365 <= ship.angle  &&
		    360/myShips.length *i -355 >= ship.angle
		){
			ship.setSpeed(5)
			ship.setAngleSpeed(0)
		}
	}else if(state == 3) {
		translate( ship, getCenter() )
		ship.setSpeed(2.5)
	}else if(state == 4) {
		for (var j = enemyShips.length - 1; j >= 0; j--) {
			var eship = enemyShips[j]
			translate( ship, eship )
			ship.setSpeed(0)
			shot = (shot++)%10
			if(shot == 0){
				ship.shoot()
			}else {
				ship.setSpeed(5)
				translate( ship, {x:ship.x - eship.y, y:ship.y - eship.y} )
			}
		}
	}
	};
}

//aaa