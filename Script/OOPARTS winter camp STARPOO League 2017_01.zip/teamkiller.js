function update(){
	var movedist=3
	var shootdist=1.5
	if(myShips.length>0){
		if(allyShips.length<=myShips.length){
			if(enemyShips.length>0){
				for(var i=0;i<myShips.length;i++){
					ship=myShips[i]
					ship.setSpeed(shipMaxSpeed)
					enemytarget=enemyShips[0]
					for(var j=0;j<enemyShips.length;j++){
						if(dist(ship, enemytarget)>dist(ship, enemyShips[j])){
							enemytarget=enemyShips[j]
						}
					}
					p=polarFrom(ship, enemytarget)
					if(p.angle<0){
						if(p.angle>360*dt){
							ship.setAngleSpeed(360)
						}
						else{
							ship.setAngleSpeed(p.angle/dt)
						}
					}
					else{
						if(p.angle<-360*dt){
							ship.setAngleSpeed(-360)
						}
						else{
							ship.setAngleSpeed(p.angle/dt)
						}
					}
					if(dist(ship, enemytarget)<movedist){
						ship.setSpeed(3)
					}
					if(dist(ship, enemytarget)<shootdist){
						ship.shoot()
					}
				}
				
			}
			else{
				ship=myShips[0]
				ship.setSpeed(5)
				var aa=polarFrom(ship, {x:0,y:0})
				if(aa.r<(0.75*groundRadius)){
					ship.setAngleSpeed((((random()*100000)%7)-3)*360)
				}
				else{
					ship.setAngleSpeed(aa.angle)
				}
				for(var l=1;l<myShips.length;l++){
					ship=myShips[l]
					ship.setSpeed(5)
					if(l<myShips.length*6/10){
						p=polarFrom(ship, myShips[0])
						if(p.angle<0){
							if(p.angle>360*dt){
								ship.setAngleSpeed(360)
							}
							else{
								ship.setAngleSpeed(p.angle/dt)
							}
						}
						else{
							if(p.angle<-360*dt){
								ship.setAngleSpeed(-360)
							}
							else{
								ship.setAngleSpeed(p.angle/dt)
							}
						}
					}
					else{
						aa=polarFrom(ship, {x:0,y:0})
						if(aa.r<(0.75*groundRadius)){
							ship.setAngleSpeed((((random()*100000)%7)-3)*360)
						}
						else{
							ship.setAngleSpeed(aa.angle)
						}
					}
				}
			}
		}
		else{/*
			for(var l=0;l<myShips.length;l++){
				ship=myShips[l]
				ship.setSpeed(5)
				var aa=polarFrom(ship, {x:0,y:0})
				if(aa.r<(0.75*groundRadius)){
					ship.setAngleSpeed((((random()*100000)%7)-3)*360)
				}
				else{
					ship.setAngleSpeed(aa.angle)
				}
			}*/
			var tt=polarFrom(myShips[0], allyShips[0])
			enemytarget=allyShips[0]
			if(tt.r==0){
				log(tt.r)
				for(var ll=0;ll<myShips.length;ll++){
					if(ll+myShips.length<allyShips.length){
						enemytarget=allyShips[ll+myShips.length]
					}
					else{
						enemytarget=allyShips[((ll+myShips.length)%(allyShips.length-myShips.length))+myShips.length]
					}
					ship=myShips[ll]
					ship.setSpeed(5)
					p=polarFrom(ship, enemytarget)
					if(p.angle<0){
						if(p.angle>360*dt){
							ship.setAngleSpeed(360)
						}
						else{
							ship.setAngleSpeed(p.angle/dt)
						}
					}
					else{
						if(p.angle<-360*dt){
							ship.setAngleSpeed(-360)
						}
						else{
							ship.setAngleSpeed(p.angle/dt)
						}
					}
					if(dist(ship, enemytarget)<2){
						ship.setSpeed(0)
						ship.shoot()
					}
				}
			}
			else{
				for(var ll=0;ll<myShips.length;ll++){
					enemytarget=allyShips[ll]
					ship=myShips[ll]
					ship.setSpeed(5)
					p=polarFrom(ship, enemytarget)
					if(p.angle<0){
						if(p.angle>360*dt){
							ship.setAngleSpeed(360)
						}
						else{
							ship.setAngleSpeed(p.angle/dt)
						}
					}
					else{
						if(p.angle<-360*dt){
							ship.setAngleSpeed(-360)
						}
						else{
							ship.setAngleSpeed(p.angle/dt)
						}
					}
					if(dist(ship, enemytarget)<2){
						ship.setSpeed(0)
						ship.shoot()
					}
				}
			}
			
			
			
			
		}
	}
}